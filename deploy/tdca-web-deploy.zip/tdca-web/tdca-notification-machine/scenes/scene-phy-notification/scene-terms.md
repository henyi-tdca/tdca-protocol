# 通知机物理锚点场景术语（scene-phy-notification）
# 版本: SCENE-TERMS-v1.0.0
# 关联: TDCA-TERMINOLOGY-REGISTRY V1.1（G-1 基线）
# FC-ID: TDCA-FC-20260811-004-NOTIFICATION-MACHINE（层 3 场景化合）
# ID92 模拟态标注: 本场景为模拟态示范

| 场景术语 | TDCA 映射 | 定义 |
|---------|----------|------|
| TDID | 硬件身份唯一标识 | TDID = SHA256(PUF指纹 ‖ 宪法哈希 ‖ 批次号)，SM2 签名防伪 |
| PUF | 物理不可克隆函数 | SRAM PUF 指纹仅存哈希，密钥材料永不落盘 |
| 五重锚定 | 地址/线路/硬件/成本/主体 | 接入 TDCA 网络的准入证明 |
| NCA-Lite | 全量 NCA（11 字段）精简版 | 8 字段芯片端轻量存证，与 TCN 全量 NCA 链式关联 |
| fact-chain | 事实哈希链 | 物理事件 → SHA-256 事实哈希 → 链式上链（O(n) 审计） |
| 物理负空间 | 绝对负空间（ID86） | 硬件安全机制即时 BLOCK，不可逆 |
| 制度负空间 | NSFL 熔断 | 协议层判定，TCN 慢系统确认，可逆至 SUSPENDED |
| 日抛调用 | DISPOSABLE | 事实哈希上链，物理叠加通道，调度税 1-3% |
| 化合调用 | COMPOUND | 通话确权/迁移，ID90 三条件闸门，调度税 + 版税 5-10% |
| MRCR | 多角色兼容性规则 | TDID ↔ 场景角色注册，场景隔离/独立审计/独立演化 |
