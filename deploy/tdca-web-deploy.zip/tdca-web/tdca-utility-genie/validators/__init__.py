"""TDCA 效用精灵 校验器包"""
from .contract_delivery_validator import ContractDeliveryValidator, DeliveryValidationReport

__all__ = ['ContractDeliveryValidator', 'DeliveryValidationReport']
