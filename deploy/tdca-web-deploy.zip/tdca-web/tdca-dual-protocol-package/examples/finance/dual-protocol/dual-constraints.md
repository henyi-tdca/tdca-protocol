# finance 双协议化合约束矩阵

TDCA 基础: 六要素标准（TDCA-CONST-v3.1.2）
场景扩展: ```yaml scene_constraints:
化合结果: TDCA 六要素 + 场景特定约束（化合）
