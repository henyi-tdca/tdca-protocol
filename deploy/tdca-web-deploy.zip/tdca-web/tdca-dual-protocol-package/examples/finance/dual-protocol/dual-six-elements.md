# finance 化合六要素模板

模板: dual-six-elements.md（化合六要素模板）
