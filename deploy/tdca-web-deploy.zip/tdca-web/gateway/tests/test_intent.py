# -*- coding: utf-8 -*-
"""意图导航端点测试（自然语言 → 功能页直达 + 操作指引）。"""
from fastapi.testclient import TestClient

from app import app

client = TestClient(app)


def _get(q):
    r = client.get(f"/api/v1/intent?q={q}")
    assert r.status_code == 200, r.text[:200]
    body = r.json()
    assert "nca_watermark" in body
    return body["data"]


def test_intent_sign():
    d = _get("我要签批一个确权申请")
    assert d["matched"] is True
    assert d["route"] == "/attestation/dynamic"
    assert d["action"] == "签批"
    assert len(d["guide"]) >= 3                     # 操作指引在位
    assert any("HUF" in step for step in d["guide"])  # 签批必含人类终裁提示


def test_intent_query_tax():
    d = _get("帮我查一下税收账单")
    assert d["route"] == "/tax"
    assert d["action"] == "查询"


def test_intent_create():
    d = _get("我想创建一个新的智能体")
    assert d["route"] == "/studio"
    assert d["action"] == "创建"


def test_intent_fallback():
    d = _get("今天天气怎么样")
    assert d["matched"] is False
    assert d["route"] == "/"                          # fail-soft 回首页 + 示例提示
    assert any("签批" in step for step in d["guide"])


def test_intent_alternatives():
    d = _get("确权和签批")                            # 多意图命中 → 备选
    assert d["matched"] is True
    assert isinstance(d["alternatives"], list)
