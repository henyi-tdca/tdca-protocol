# TDCA 连接器 v1.0 出包（tdca-connector-v1.0.zip）

> 版本：v1.0 ｜ 来源：TDCA 协议仓 `tools/connector-v2/`（main 提交 `8e15301`）＋ `tools/tests/test_connector_v2.py`
> 许可：Apache-2.0（源码 SPDX 头在包内）
> 性质：对外工具包（公开货架件）；内容为仓内公开区源码的出包副本，功能与仓内一致

## 一、这是什么

TDCA 连接器两件套：

- **adapter_matcher.py（适配器匹配辅助）**：输入合规标准条款（如「最小权限」「人工确认」「熔断」），输出 Top-K 匹配的 TDCA 原理条目（公开原理表）＋得分与命中词，辅助适配器实例填写映射详表。
- **cop_connector.py（连接器本体）**：TF-IDF 加权 + 多维语义匹配（soul / primitives / decision 三维加余弦合成）+ 负空间反向降权的「场景 → 思维协议（COP）语料」匹配器；核心打分 `U = U₀ · SC · A`。

## 二、文件清单

| 文件 | 说明 | 人读／机读 |
|---|---|---|
| `adapter_matcher.py` | 适配器匹配辅助（单文件可跑） | 机读（直接执行） |
| `cop_connector.py` | 连接器本体（需 COP 语料目录） | 机读（直接执行） |
| `selftest.py` | 随包自测（零第三方依赖） | 机读 |
| `tests/test_connector_v2.py` | 完整行为测试套件（pytest） | 机读 |
| `sample-workspace/.../cop-library/` | 2 件演示 COP 语料（合成数据） | 机读（样例输入） |

## 三、依赖声明（如实）

| 件 | 运行依赖 | 说明 |
|---|---|---|
| `adapter_matcher.py` | **零第三方依赖**（纯 Python 标准库） | 若环境有 jieba 则自动启用分词增强，缺省回退内置 n-gram，不影响功能 |
| `cop_connector.py` | **PyYAML（必需）** | `import yaml` 为硬依赖，未安装时导入即退出码 2 并明示 |
| `selftest.py` | 零第三方依赖 | 因加载 `cop_connector`，需 PyYAML 方可跑全；缺 PyYAML 时退出码 2 并明示 |
| `tests/` | pytest + PyYAML | 标准测试依赖 |

## 四、用法

```bash
python adapter_matcher.py     # 内置 6 条款演示，直接出结果
python cop_connector.py       # 需 COP 语料：设 TDCA_WS 指向含 tdca-thinktank/.../cop-library 的工作区
python selftest.py            # 随包自测；本包已带 sample-workspace，开箱可跑
python -m pytest tests/ -q    # 完整套件（需 pytest + PyYAML）
```

自测退出码约定：`0` = 全部通过；`1` = 有自检项失败（末行 [FAIL] 明细）；`2` = 环境前提不满足（缺 PyYAML 或未找到 COP 语料，末行 [PREREQ]/[FAIL] 明示，**不静默空跑**）。

## 五、适用域与不适用域

**适用**：合规条款到 TDCA 原理的映射辅助；场景描述到 COP 语料的语义检索排序；适配器实例映射详表填写的候选生成。

**不适用（不该用）**：
- 不是合规裁决工具——输出仅为相似度候选，最终映射须人工核定；
- 不是法律／审计意见——得分无外部校准含义，不可对外宣称「合规认证」；
- 不适用于无 COP 语料的环境（连接器本体空跑无意义，件内已做退出码 2 防呆）；
- `adapter_matcher` 的原理表是固定精选子集，未覆盖全部原理条目。

## 六、边界与已知事项

- `cop_connector.py` 的 COP 语料路径三段式解析：① 环境变量 `TDCA_WS` 覆盖 → ② 仓内相对探测 → ③ 均不成立退出码 2。出包环境无仓，须显式设 `TDCA_WS`（本包样例：`TDCA_WS=<包根>/sample-workspace`）。
- 出包相对仓内版本的差异（仅两处，均不改算法语义）：① 测试件的被测路径由「仓内 connector-v2 目录」改为「包根」；② 语料解析测试由「仓内真实语料」改为「包内样例语料（2 件，计数断言相应改为等于 2）」。源码本体逐字未动。
- 六模式复扫：`adapter_matcher.py` 原理表键为「大写字母 I 开头后接两位数字」样式（共 26 条，如原理表内的固定键名），属公开原理表数据而非内部件流水编号；其余件 0 命中。此样式命中已照实列明，处置以货架定稿为准。
- 样例语料为合成演示数据，已在件内标注，不冒充真实运行协议。

## 七、速查

| 要做什么 | 命令 |
|---|---|
| 看条款匹配演示 | `python adapter_matcher.py` |
| 跑随包自测 | `python selftest.py`（期望末行 `[OK]`，退出码 0） |
| 跑完整测试 | `python -m pytest tests/ -q`（12 例） |
| 换自己的语料 | `set TDCA_WS=<含 tdca-thinktank/.../cop-library 的工作区>` 后跑 `python cop_connector.py` |
| 排查环境问题 | 退出码 2 时看末行 `[PREREQ]`／`[FAIL]` 明示 |

*出包：TDCA 执行侧 · v1.0 · 构建自 main `8e15301`；本包不宣称任何合规、认证或审计效力。*
