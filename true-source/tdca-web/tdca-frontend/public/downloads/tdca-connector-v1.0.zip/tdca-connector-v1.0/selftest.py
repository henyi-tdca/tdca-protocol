# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
"""tdca-connector-v1.0 随包自测（零第三方依赖；退出码约定见下）

退出码：
  0 = 全部自检通过
  1 = 有自检项失败（输出末行 [FAIL] 明细）
  2 = 环境前提不满足（缺 PyYAML，cop_connector 无法导入；输出末行 [PREREQ]）

用法：
  python selftest.py
"""
import importlib.util
import sys
import tempfile
from collections import Counter
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')

PKG = Path(__file__).resolve().parent
FAILS = []

# 包内样例语料：cop_connector 导入即解析 COP_DIR，须先备好环境变量
import os
os.environ.setdefault("TDCA_WS", str(PKG / "sample-workspace"))


def check(name, fn):
    try:
        fn()
        print(f"[PASS] {name}")
    except Exception as e:  # noqa: BLE001 - 自测需全捕
        FAILS.append(f"{name}: {e!r}")
        print(f"[FAIL] {name}: {e!r}")


def _load(name):
    spec = importlib.util.spec_from_file_location(name, PKG / f"{name}.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# 环境前提：cop_connector 硬依赖 PyYAML
try:
    cc = _load("cop_connector")
except ImportError as e:
    print(f"[PREREQ] cop_connector 导入失败（缺 PyYAML？）：{e!r}")
    print("[PREREQ] 安装：pip install pyyaml 后重跑本脚本")
    sys.exit(2)

am = _load("adapter_matcher")


def t_am_tokenize():
    toks = am.tokenize("熔断，限制 A1 99% 的权限")
    assert "熔断" in toks and "限制" in toks
    assert not any(t.isdigit() or t.endswith("%") for t in toks)
    assert all(len(t) >= 2 for t in toks)


def t_am_match_order():
    res = am.match_clause("最小权限：仅授予最低权限，分级授权", top_k=5)
    assert 0 < len(res) <= 5
    scores = [r["score"] for r in res]
    assert scores == sorted(scores, reverse=True)
    for r in res:
        assert set(r) >= {"id", "name", "score", "hit"}
        assert r["id"] in am.PRINCIPLES


def t_am_empty():
    assert am.match_clause("") == []
    assert am.match_clause("，。、") == []


def t_cc_u0():
    assert cc.compute_u0({"validated": False, "n_prims": 4, "n_dec": 4, "nca_emit": True}) == 0.0
    assert cc.compute_u0({"validated": True, "n_prims": 0, "n_dec": 0, "nca_emit": False}) == 0.6
    assert cc.compute_u0({"validated": True, "n_prims": 4, "n_dec": 4, "nca_emit": True}) == 1.0


def _mk_cop(neg=None):
    return {
        "cop_id": "T1", "identity": "协作调度身份", "category": "测试类", "core": "正和涌现",
        "soul_vec": Counter({"协作调度": 2, "正和": 1}),
        "prim_vec": Counter({"协作调度": 1}),
        "decision_vec": Counter({"协作": 1}),
        "negative_terms": set(neg or []),
        "validated": True, "n_prims": 1, "n_dec": 1, "nca_emit": True,
    }


def t_cc_neg_space():
    scene = "协作调度 正和 协作"
    base = cc.match(scene, [_mk_cop()], top_k=1)[0]["A"]
    lowered = cc.match(scene, [_mk_cop(neg=["协作调度"])], top_k=1)[0]["A"]
    assert abs(lowered - base * 0.5) < 1e-3  # 负空间 ≥3 字命中 → A 减半
    short = cc.match(scene, [_mk_cop(neg=["协作"])], top_k=1)[0]["A"]  # 仅 2 字不触发
    assert short == cc.match(scene, [_mk_cop()], top_k=1)[0]["A"]


def t_cc_match_empty():
    assert cc.match("任何场景", [], top_k=5) == []


def t_cc_load_cops():
    import yaml  # 前提已验证可达
    # ① 包内默认语料可载
    assert len(cc.load_cops(str(cc.COP_DIR))) == 2
    # ② 坏件/无 soul 件跳过
    with tempfile.TemporaryDirectory() as d:
        good = {"COP-ID": "GOOD", "validation": {"passed": True},
                "soul": {"identity": "x", "core": "正和", "role": "r", "category": "测试类"},
                "primitives": [{"method": "m", "precond": "p", "postcond": "q", "nca_emit": True}],
                "decision": [{"if": "协作", "call": "f"}], "negative_space": ["数据泄露"]}
        (Path(d) / "good.yaml").write_text(yaml.safe_dump(good, allow_unicode=True), encoding="utf-8")
        (Path(d) / "nosoul.yaml").write_text(yaml.safe_dump({"COP-ID": "X"}), encoding="utf-8")
        (Path(d) / "broken.yaml").write_text("::not yaml::", encoding="utf-8")
        cops = cc.load_cops(d)
        assert len(cops) == 1 and cops[0]["cop_id"] == "GOOD"
        assert "数据泄露" in cops[0]["negative_terms"]


check("adapter_matcher.tokenize 过滤规则", t_am_tokenize)
check("adapter_matcher.match_clause 排序与结构", t_am_match_order)
check("adapter_matcher 空条款边界", t_am_empty)
check("cop_connector.compute_u0 三分支", t_cc_u0)
check("cop_connector 负空间反向降权", t_cc_neg_space)
check("cop_connector 空 COP 集边界", t_cc_match_empty)
check("cop_connector.load_cops 坏件跳过", t_cc_load_cops)

print("-" * 60)
if FAILS:
    print(f"[FAIL] {len(FAILS)} 项未过：")
    for f in FAILS:
        print("  -", f)
    sys.exit(1)
print(f"[OK] 全部 7 项自检通过（am 原理表 {len(am.PRINCIPLES)} 条）")
sys.exit(0)
