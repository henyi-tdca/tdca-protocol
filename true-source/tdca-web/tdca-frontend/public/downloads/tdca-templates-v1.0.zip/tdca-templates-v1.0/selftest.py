# -*- coding: utf-8 -*-
"""tdca-templates-v1.0 随包自测（零第三方依赖；退出码约定见下）

自检内容：
  1. 21 件模板全数在包（清单核对，缺一件即失败）；
  2. 每件 sha256 与出包清单一致（改动任一字即失败）；
  3. 机读 YAML 件可解析（若环境有 PyYAML；无则跳过并明示，不算失败）。

退出码：
  0 = 全部通过
  1 = 有失败项（[FAIL] 明细）
  2 = 用法错误（本脚本须在包根目录下运行）

用法：
  python selftest.py
"""
import hashlib
import json
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')

PKG = Path(__file__).resolve().parent
MANIFEST = json.loads((PKG / 'file-manifest.json').read_text(encoding='utf-8'))


def main():
    if not (PKG / 'file-manifest.json').is_file():
        print('[FAIL] file-manifest.json 不在包根')
        return 1
    fails = []
    # ① 全数在包
    on_disk = {p.relative_to(PKG).as_posix() for p in PKG.rglob('*') if p.is_file()
               and p.relative_to(PKG).as_posix() not in ('selftest.py', 'file-manifest.json', 'README.md')}
    missing = sorted(set(MANIFEST) - on_disk)
    extra = sorted(on_disk - set(MANIFEST))
    if missing:
        fails.append(f'缺件 {len(missing)}：{missing}')
    if extra:
        fails.append(f'多出未列件 {len(extra)}：{extra}')
    # ② 哈希一致
    for rel, want in sorted(MANIFEST.items()):
        p = PKG / rel
        if not p.is_file():
            continue  # 已在上项报缺
        got = hashlib.sha256(p.read_bytes()).hexdigest()
        if got != want:
            fails.append(f'哈希不符：{rel}')
    for f in fails:
        print('[FAIL]', f)
    # ③ YAML 可解析（可选）
    yaml_files = [r for r in MANIFEST if r.endswith('.yaml')]
    try:
        import yaml  # noqa: F401
        for rel in yaml_files:
            p = PKG / rel
            if not p.is_file():
                continue
            try:
                yaml.safe_load(p.read_text(encoding='utf-8'))
            except Exception as e:  # noqa: BLE001
                fails.append(f'YAML 解析失败：{rel}: {e!r}')
                print('[FAIL] YAML 解析失败：', rel, repr(e))
        print(f'[INFO] PyYAML 在位：{len(yaml_files)} 件 YAML 全部解析通过')
    except ImportError:
        print(f'[INFO] 无 PyYAML：跳过 YAML 解析（{len(yaml_files)} 件）；件数与哈希核对不受影响')
    print('-' * 60)
    if fails:
        print(f'[FAIL] {len(fails)} 项未过')
        return 1
    print(f'[OK] 全部 {len(MANIFEST)} 件在包且哈希逐位一致')
    return 0


if __name__ == '__main__':
    if not (PKG / 'contracts').is_dir():
        print('[FAIL] 未在包根运行（找不到 contracts/ 目录）')
        sys.exit(2)
    sys.exit(main())
