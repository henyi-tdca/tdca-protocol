# -*- coding: utf-8 -*-
"""tdca-skills-v1.0 随包自测（零第三方依赖；退出码约定见下）

自检内容：
  1. 5 件 SKILL.md 全数在包且非空；
  2. 每件 sha256 与出包清单一致；
  3. 每件均引用仓内公开工具路径（tools/ 前缀存在性）；
  4. 包内自检：无本机绝对路径样式（盘符前缀／用户目录前缀）。

退出码：
  0 = 全部通过
  1 = 有失败项（[FAIL] 明细）
  2 = 用法错误（须在包根运行）

用法：
  python selftest.py
"""
import hashlib
import json
import re
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')

PKG = Path(__file__).resolve().parent
LOCAL = re.compile(r'[A-Za-z]:[\\/]|[\\/]Users[\\/]|[\\/]home[\\/]')


def main():
    manifest_p = PKG / 'file-manifest.json'
    if not manifest_p.is_file():
        print('[FAIL] file-manifest.json 不在包根')
        return 1
    manifest = json.loads(manifest_p.read_text(encoding='utf-8'))
    fails = []
    for rel, want in sorted(manifest.items()):
        p = PKG / rel
        if not p.is_file():
            fails.append(f'缺件：{rel}')
            print('[FAIL] 缺件：', rel)
            continue
        data = p.read_bytes()
        if not data.strip():
            fails.append(f'空件：{rel}')
            print('[FAIL] 空件：', rel)
        got = hashlib.sha256(data).hexdigest()
        if got != want:
            fails.append(f'哈希不符：{rel}')
            print('[FAIL] 哈希不符：', rel)
        txt = data.decode('utf-8', errors='replace')
        if 'tools/' not in txt:
            fails.append(f'未引用 tools/ 公开路径：{rel}')
            print('[FAIL] 未引用 tools/ 公开路径：', rel)
        m = LOCAL.findall(txt)
        if m:
            fails.append(f'本机路径样式命中 {len(m)}：{rel}')
            print('[FAIL] 本机路径样式：', rel, m[:3])
    print('-' * 60)
    if fails:
        print(f'[FAIL] {len(fails)} 项未过')
        return 1
    print(f'[OK] 全部 {len(manifest)} 件在包、哈希一致、引用 tools/ 公开路径、无本机路径样式')
    return 0


if __name__ == '__main__':
    if not (PKG / 'skills').is_dir():
        print('[FAIL] 未在包根运行（找不到 skills/ 目录）')
        sys.exit(2)
    sys.exit(main())
