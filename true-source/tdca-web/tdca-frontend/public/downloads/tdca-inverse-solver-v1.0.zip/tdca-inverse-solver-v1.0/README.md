# TDCA 反函数求解器 v1.0 出包（tdca-inverse-solver-v1.0.zip）

> 版本：v1.0 ｜ 来源：TDCA 协议仓 `tdca-utility-genie/solvers/inverse_function_solver.py`（main 提交 `8e15301`）＋对应测试件
> 许可：Apache-2.0（LICENSE 全文与 SPDX 头在包内）｜ 本包为 TDCA 自研件，许可由 TDCA 自选（原「内部使用」自选标注，本轮自选改标对外公开）
> 性质：对外工具包（公开货架件）；源码算法与功能与仓内逐字一致，仅头部制度锚定引用按出包纪律剥离（脱敏）

## 一、这是什么

**反函数求解器**：给定目标效用 `U_target` 与效用函数 `f`，在配置权可行域（边界＋硬约束）内反推配置向量 `X`，使 `f(X) ≥ U_target`；多解时按总成本最小（其次效用最大）择优；无可行解时不静默返回，触发负空间熔断（`NSFL-TRIGGER`）并给出不可行结论与原因。

随机采样（默认 1000 点，可设 `samples`／`random_seed`）＋硬约束预筛＋择优排序；结果含预测效用、置信区间（候选解效用 min-max）、可行性三态（feasible / infeasible / conditional 字段预留）与求解轨迹。

## 二、文件清单

| 文件 | 说明 | 人读／机读 |
|---|---|---|
| `solvers/inverse_function_solver.py` | 求解器本体（dataclass 配置域／解结构＋求解＋自证 validate） | 机读 |
| `solvers/__init__.py` | 包导出（出包版仅导反函数求解器一件） | 机读 |
| `selftest.py` | 随包自测（4 项） | 机读 |
| `tests/test_inverse_function_solver.py` | unittest 套件（6 例） | 机读 |

## 三、依赖声明（如实）

**零第三方依赖**：纯 Python 标准库（`dataclasses`／`typing`／`random`／`unittest`），Python ≥ 3.8 可跑。无隐藏依赖，venv 空环境可直接复跑下方全部命令自证。

## 四、适用域与不适用域（重点）

**适用域**：
- 目标效用已给定、需反推资源配置的优化场景（资源配额／参数调优／预算分配类问题）；
- 效用函数可黑箱调用（只需 `f(config) -> float`）、配置域可 box 约束（上下界＋线性硬约束）的问题；
- 需要「无解即熔断并留痕」语义、不接受静默失败的自动化链路。

**不适用域（不该用）**：
- 非凸高维精密优化：本求解器是随机采样＋择优的**基线启发式**，非贝叶斯优化／梯度法实现，高精度或高维（>10 维）问题请用专业优化库；
- 硬约束仅支持 `key <= / >= / < / > value` 简单式，复杂约束（耦合、非线性）不在解析范围；
- 不可用于安全关键决策的终局裁决：输出为启发式候选解，须人工复核后执行；
- `validate` 是一致性自证（可行性／熔断记录／效用非负），不构成外部合规认证。

## 五、用法

```bash
python selftest.py                              # 随包自测（期望 [OK]，退出码 0）
python -m unittest discover -s tests -v         # 完整套件（6 例）
```

编程调用：

```python
from solvers.inverse_function_solver import InverseFunctionSolver, ConfigSpace
solver = InverseFunctionSolver(samples=2000, random_seed=42)
sol = solver.solve(target_utility=5.0, utility_function=lambda c: c['x'],
                   config_space=ConfigSpace(bounds={'x': (0.0, 10.0)}, hard_constraints=['x <= 10']),
                   cost_function=lambda c: c['x'], tolerance=0.1)
solver.validate(sol)   # 自证：不合规即抛 ValueError（含 [NSFL-TRIGGER] 标记）
```

自测退出码约定：`0` = 全部通过；`1` = 有失败项（[FAIL] 明细）；`2` = 用法／环境错误（本包零依赖，正常环境不应出现）。

## 六、边界与已知事项

- 出包脱敏：原源码 docstring 的制度锚定引用行（函数隐喻／效用精灵条目引用与授权行）已剥离，类注释与测试头同步脱敏；**算法、接口、用例逐字未动**（diff 仅头部 docstring）。
- 求解器内「负空间熔断」为语义约束（无解即显式熔断并留痕），非运行时安全沙箱。
- 许可改标（承放行令）：本包为 TDCA 自研件（无上游代码痕迹，非挂载／适配／化合），许可由 TDCA 自选——原自选标注 `TDCA-Internal`（内部使用），本轮自选改标 `Apache-2.0` 对外公开；LICENSE 标准全文在包根，SPDX 头同步改标。
- 六模式复扫：全包 0 命中（脱敏后）。

## 七、速查

| 要做什么 | 命令／写法 |
|---|---|
| 跑随包自测 | `python selftest.py` |
| 跑完整测试 | `python -m unittest discover -s tests -v` |
| 求反函数解 | `solver.solve(target_utility, utility_function, config_space)` |
| 设硬约束 | `ConfigSpace(bounds={...}, hard_constraints=['x <= 10'])` |
| 无解行为 | 返回 `feasibility='infeasible'`＋空配置＋`NSFL-TRIGGER` 轨迹 |
| 自证 | `solver.validate(solution)`，不合规抛 `ValueError` |

*出包：TDCA 执行侧 · v1.0 · 构建自 main `8e15301`；本包不宣称任何合规、认证或审计效力。*
