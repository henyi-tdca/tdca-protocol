# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
"""信箱常态台账 v1.1（修订：增 `ACKED` 已收认领态；裁定依据在册）

⭐ 用法：
  python _mailbox_ledger_v1.py            # 扫描并刷新台账（保留既有 state/basis/note/ack_*）
  python _mailbox_ledger_v1.py --check    # 只对账，不改台账
  python _mailbox_ledger_v1.py --ack <件名片段> --evidence <凭据件号> --sha16 <原件哈希16> [--by EXEC|WB]
                                          # 注入 ACKED（须凭据件号 ＋ 原件哈希，⛔ 口称即认）
  [--mailbox-root <路径>]                 # 信箱根，默认取脚本同级 mailbox/
  [--data-format auto|yaml|json]          # 后端选择，默认 auto（有 PyYAML 用 YAML，无则 JSON）
⭐ 六态：NEW（新投未判读）／PENDING（已判读·待补核）／VERIFIED（已核出件）／ACKED（对方已确认收到·本侧未核）／
        CLOSED（已收口归档）／SENT（已发出，待对方取用）
⭐ 发件夹（TO-EXEC／TO-WB）之件记 SENT 或 ACKED（有凭据者转 ACKED）
⭐ ⚠️ 认领**不设时限**（照在册裁定「认领不用取值」）⟹ 本器 ⛔ 判超期、⛔ 立超期清单、⛔ 区分「取了未回／在办」
⭐ 台账件落信箱根内：mailbox-ledger.yaml（YAML 后端）／mailbox-ledger.json（JSON 后端）
"""
import hashlib
import io
import os
import subprocess
import sys
from datetime import datetime

try:  # 双后端：有 PyYAML 用 YAML，无则读 JSON（零依赖路径）
    import yaml
    _YAML_OK = True
except ImportError:
    yaml = None
    _YAML_OK = False
import json
import os as _os
if _os.environ.get("TDCA_MB_NOYAML"):
    _YAML_OK = False

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_BOX = os.path.join(SCRIPT_DIR, "mailbox")

IN_BOXES = ["FROM-EXEC", "FROM-WB"]
OUT_BOXES = ["TO-EXEC", "TO-WB"]
ARCHIVE = ["DONE"]
STATES = ["NEW", "PENDING", "VERIFIED", "ACKED", "CLOSED", "SENT"]
ACK_KEYS = ["ack_at", "ack_by", "ack_evidence", "ack_sha16"]

CFG = {"box": DEFAULT_BOX, "ledger_yaml": "", "ledger_json": "", "use_yaml": False}


def init_paths(mailbox_root, data_format):
    box = os.path.abspath(mailbox_root)
    CFG["box"] = box
    CFG["ledger_yaml"] = os.path.join(box, "mailbox-ledger.yaml")
    CFG["ledger_json"] = os.path.join(box, "mailbox-ledger.json")
    if data_format == "yaml":
        if not _YAML_OK:
            print("UNKNOWN 指定 --data-format yaml 但无 PyYAML，不可得")
            raise SystemExit(2)
        CFG["use_yaml"] = True
    elif data_format == "json":
        CFG["use_yaml"] = False
    else:  # auto
        CFG["use_yaml"] = _YAML_OK


def sha16(p):
    with open(p, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest().upper()[:16]


def scan():
    """返回 { (box, filename): {size, sha256_16, mtime} }"""
    out = {}
    for box in IN_BOXES + OUT_BOXES + ARCHIVE:
        d = os.path.join(CFG["box"], box)
        if not os.path.isdir(d):
            continue
        for f in os.listdir(d):
            if not f.lower().endswith((".md", ".json")):
                continue
            p = os.path.join(d, f)
            if not os.path.isfile(p):
                continue
            out[(box, f)] = {
                "size": os.path.getsize(p),
                "sha256_16": sha16(p),
                "mtime": datetime.fromtimestamp(os.path.getmtime(p)).strftime("%Y-%m-%d %H:%M"),
            }
    return out


def load_ledger():
    if CFG["use_yaml"] and os.path.exists(CFG["ledger_yaml"]):
        return yaml.safe_load(io.open(CFG["ledger_yaml"], encoding="utf-8")) or {}
    if os.path.exists(CFG["ledger_json"]):
        with io.open(CFG["ledger_json"], encoding="utf-8") as f:
            return json.load(f) or {}
    if os.path.exists(CFG["ledger_yaml"]):
        print("UNKNOWN 读数不可得：无 PyYAML 且无 JSON 后端，请改 --data-format 或先备 JSON 副本")
        raise SystemExit(2)
    return {}


def _save(doc):
    if CFG["use_yaml"]:
        os.makedirs(os.path.dirname(CFG["ledger_yaml"]), exist_ok=True)
        with io.open(CFG["ledger_yaml"], "w", encoding="utf-8", newline="\n") as f:
            yaml.dump(doc, f, allow_unicode=True, sort_keys=False)
        print(f"  台账已写：{CFG['ledger_yaml']}")
    else:
        os.makedirs(os.path.dirname(CFG["ledger_json"]), exist_ok=True)
        with io.open(CFG["ledger_json"], "w", encoding="utf-8", newline="\n") as f:
            json.dump(doc, f, ensure_ascii=False, indent=1)
        print(f"  台账已写（JSON 后端）：{CFG['ledger_json']}")


def build(disk, old):
    """合并：磁盘为准，保留既有 state/basis/note/ack_*（按文件名匹配）"""
    prev = {}
    for it in (old.get("items") or []):
        prev[it.get("file")] = it
    items = []
    for (box, fn), meta in sorted(disk.items(), key=lambda kv: (kv[0][0], kv[0][1])):
        p = prev.get(fn, {})
        if box in ARCHIVE:
            state = "CLOSED"
        elif box in OUT_BOXES:
            # ⭐ ACKED 由「凭据」决定，⛔ 因磁盘位置变而回落 SENT
            state = "ACKED" if p.get("state") == "ACKED" else "SENT"
        else:
            state = p.get("state") if p.get("state") in ("NEW", "PENDING", "VERIFIED", "ACKED") else "NEW"
        row = {
            "file": fn,
            "box": box,
            "size": meta["size"],
            "sha256_16": meta["sha256_16"],
            "received_at": meta["mtime"],
            "state": state,
            "basis": p.get("basis", ""),
            "note": p.get("note", ""),
            "closed_at": p.get("closed_at", meta["mtime"] if state == "CLOSED" else ""),
        }
        for k in ACK_KEYS:
            row[k] = p.get(k, "")
        items.append(row)
    return items


def reconcile(items, disk):
    """四类不一致（第四类为 L1-SI-172 新增：ACKED 无凭据）"""
    led = {(i["box"], i["file"]) for i in items}
    loose = [k for k in disk if k not in led]                      # 盘上有、台账无
    ghost = [k for k in led if k not in disk]                      # 台账有、盘上无
    mismatch = []                                                  # 状态与夹不符
    ack_loose = []                                                 # ACKED 却无凭据
    for i in items:
        box, st = i["box"], i["state"]
        if box in ARCHIVE and st != "CLOSED":
            mismatch.append((i["file"], f"在 {box} 但状态 {st}"))
        if box in IN_BOXES and st == "CLOSED":
            mismatch.append((i["file"], "在收件夹但状态 CLOSED"))
        if box in OUT_BOXES and st not in ("SENT", "ACKED"):
            mismatch.append((i["file"], f"在发件夹但状态 {st}"))
        if st == "ACKED" and not (i.get("ack_evidence") and i.get("ack_sha16")):
            ack_loose.append((i["file"], "ACKED 缺 ack_evidence 或 ack_sha16"))
    return loose, ghost, mismatch, ack_loose


def do_ack(items, pat, evidence, sha, by):
    hits = [i for i in items if pat in i["file"]]
    if not hits:
        print("⛔ 无匹配：", pat)
        return 2
    if len(hits) > 1:
        print("⛔ 片段多命中，请写长一点：", [h["file"][:50] for h in hits])
        return 2
    it = hits[0]
    if not evidence or not sha:
        print("⛔ 凭据不全：须 --evidence 与 --sha16（⛔ 口称即认）")
        return 2
    if sha.upper()[:16] != it["sha256_16"]:
        print(f"⛔ 哈希不符：给定 {sha.upper()[:16]} ≠ 台账 {it['sha256_16']}（防串件）")
        return 2
    if it["box"] in ARCHIVE:
        print("⛔ 该件已收口（DONE/CLOSED），⛔ 回退态；如需更正请出更正件")
        return 2
    it["state"] = "ACKED"
    it["ack_at"] = datetime.now().strftime("%Y-%m-%dT%H:%M+08:00")
    it["ack_by"] = by
    it["ack_evidence"] = evidence
    it["ack_sha16"] = sha.upper()[:16]
    print(f"→ ACKED：{it['file'][:56]} ｜ 凭据 {evidence} ｜ by {by}")
    return 0


def main():
    check_only = "--check" in sys.argv
    mroot = DEFAULT_BOX
    if "--mailbox-root" in sys.argv:
        mroot = sys.argv[sys.argv.index("--mailbox-root") + 1]
    dfmt = "auto"
    if "--data-format" in sys.argv:
        dfmt = sys.argv[sys.argv.index("--data-format") + 1]
    init_paths(mroot, dfmt)
    if "--ack" in sys.argv:
        i = sys.argv.index("--ack")
        pat = sys.argv[i + 1]
        evidence = sys.argv[sys.argv.index("--evidence") + 1] if "--evidence" in sys.argv else ""
        sha = sys.argv[sys.argv.index("--sha16") + 1] if "--sha16" in sys.argv else ""
        by = sys.argv[sys.argv.index("--by") + 1] if "--by" in sys.argv else "unknown"
        disk = scan()
        old = load_ledger()
        items = build(disk, old)
        rc = do_ack(items, pat, evidence, sha, by)
        if rc == 0:
            loose, ghost, mismatch, ack_loose = reconcile(items, disk)
            counts = {}
            for it in items:
                counts[it["state"]] = counts.get(it["state"], 0) + 1
            doc = {
                "generated_at": datetime.now().strftime("%Y-%m-%dT%H:%M:%S+08:00"),
                "version": "V1.1",
                "states_def": STATES_DEF,
                "rule": "每件必有一条台账行；无台账行不得开工核；台账状态须与磁盘位置一致（本脚本对账）",
                "counts": counts,
                "reconcile": {
                    "disk_without_ledger": [f"{b}/{f}" for b, f in loose],
                    "ledger_without_disk": [f"{b}/{f}" for b, f in ghost],
                    "state_box_mismatch": [f"{f} → {r}" for f, r in mismatch],
                    "acked_without_evidence": [f"{f} → {r}" for f, r in ack_loose],
                },
                "items": items,
            }
            _save(doc)
        return rc

    disk = scan()
    old = load_ledger()
    items = build(disk, old)
    loose, ghost, mismatch, ack_loose = reconcile(items, disk)

    counts = {}
    for i in items:
        counts[i["state"]] = counts.get(i["state"], 0) + 1

    inbox_pending = [i for i in items if i["box"] in IN_BOXES and i["state"] in ("NEW", "PENDING")]
    sent = [i for i in items if i["box"] in OUT_BOXES]
    sent_ack = [i for i in sent if i["state"] == "ACKED"]
    sent_noack = [i for i in sent if i["state"] == "SENT"]

    print(f"=== 信箱台账 v1.1 {'（只对账）' if check_only else '（刷新）'}")
    print(f"  扫描件数 {len(disk)}｜台账条目 {len(items)}")
    print("  状态分布：" + "／".join(f"{k} {counts[k]}" for k in STATES if k in counts))
    print(f"  ⚠️ 盘上有台账无 {len(loose)}｜台账有盘上无 {len(ghost)}｜状态与夹不符 {len(mismatch)}"
          f"｜ACKED 无凭据 {len(ack_loose)}")
    for x in (loose + ghost)[:5]:
        print("     ", x)
    for x in mismatch[:5]:
        print("     mismatch:", x)
    for x in ack_loose[:5]:
        print("     ack-loose:", x)
    print(f"  📤 发件：有凭据（ACKED）{len(sent_ack)} 件 ／ 无凭据 {len(sent_noack)} 件"
          "（⚠️ 认领不设时限，⛔ 判超期）")
    print(f"  📥 收件夹待处理（NEW/PENDING）{len(inbox_pending)} 件：")
    for i in inbox_pending:
        print(f"     [{i['state']}] {i['file'][:64]}  {i['size']}B  {i['sha256_16']}")

    if not check_only:
        doc = {
            "generated_at": datetime.now().strftime("%Y-%m-%dT%H:%M:%S+08:00"),
            "version": "V1.1",
            "states_def": STATES_DEF,
            "rule": "每件必有一条台账行；无台账行不得开工核；台账状态须与磁盘位置一致（本脚本对账）",
            "counts": counts,
            "reconcile": {
                "disk_without_ledger": [f"{b}/{f}" for b, f in loose],
                "ledger_without_disk": [f"{b}/{f}" for b, f in ghost],
                "state_box_mismatch": [f"{f} → {r}" for f, r in mismatch],
                "acked_without_evidence": [f"{f} → {r}" for f, r in ack_loose],
            },
            "items": items,
        }
        _save(doc)
    print("  === 完成 ===")
    return 0


STATES_DEF = {
    "NEW": "新投箱、未判读",
    "PENDING": "已判读、判定待补核",
    "VERIFIED": "已出核证/裁定件并在册（basis 填件号）",
    "ACKED": "对方已确认收到（凭据件号＋原件哈希），本侧尚未核证实质内容；⛔ 等于核证",
    "CLOSED": "已核并归档 DONE（basis + closed_at）",
    "SENT": "本侧已发出（发件夹），对方是否收到无凭据",
}

if __name__ == "__main__":
    sys.exit(main())
