# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
"""双向信箱扫描器（本侧 · 只读入站，不代执行）

用途：每轮开工扫信箱入站夹，列出未处理件；`--done` 把已核件移入 DONE。
纪律：⛔ 不删件；⛔ 不改件内容；⛔ 不代执行侧动作。

用法：
  python _mailbox_scan.py                        # 列出未处理入站件
  python _mailbox_scan.py --json                 # 机器可读
  python _mailbox_scan.py --done ID              # 把已处理件移入 DONE（按 id 前缀或文件名片段）
  python _mailbox_scan.py --mailbox-root <路径>  # 信箱根，默认取脚本同级 mailbox/
"""
import argparse
import hashlib
import json
import os
import shutil
import sys
from datetime import datetime

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_BOX = os.path.join(SCRIPT_DIR, "mailbox")
BOXES = {"exec": "FROM-EXEC", "wb": "FROM-WB"}  # 走查侧入站件
IN = OUT = DONE = None


def set_root(root):
    global IN, OUT, DONE
    MB = os.path.abspath(root)
    IN = os.path.join(MB, "FROM-EXEC")
    OUT = os.path.join(MB, "TO-EXEC")
    DONE = os.path.join(MB, "DONE")


def sha16(p):
    with open(p, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest().upper()[:16]


def scan(path):
    if not os.path.isdir(path):
        return []
    rows = []
    for fn in sorted(os.listdir(path)):
        fp = os.path.join(path, fn)
        if not os.path.isfile(fp):
            continue
        st = os.stat(fp)
        rows.append({
            "file": fn,
            "bytes": st.st_size,
            "mtime": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
            "sha256_16": sha16(fp),
        })
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--box", choices=sorted(BOXES), default="exec",
                    help="入站信箱：exec=FROM-EXEC（默认）／wb=FROM-WB（走查侧）")
    ap.add_argument("--done", metavar="PAT", help="把匹配的入站件移入 DONE")
    ap.add_argument("--mailbox-root", default=DEFAULT_BOX, help="信箱根（默认脚本同级 mailbox/）")
    a = ap.parse_args()
    set_root(a.mailbox_root)

    IN = os.path.join(os.path.dirname(DONE), BOXES[a.box])

    if a.done:
        hits = [r for r in scan(IN) if a.done in r["file"]]
        if not hits:
            print("⛔ 无匹配：", a.done)
            return 2
        os.makedirs(DONE, exist_ok=True)
        for r in hits:
            src = os.path.join(IN, r["file"])
            dst = os.path.join(DONE, r["file"])
            if os.path.exists(dst):
                dst = dst + "." + datetime.now().strftime("%H%M%S")
            shutil.move(src, dst)
            print("→ DONE:", r["file"], "|", r["sha256_16"])
        return 0

    pending = scan(IN)
    sent = scan(OUT)
    if a.json:
        print(json.dumps({"inbox": pending, "outbox": sent}, ensure_ascii=False, indent=2))
        return 0

    print("=" * 62)
    print("入站 FROM-EXEC  待核:", len(pending))
    for r in pending:
        print(f"  [{r['sha256_16']}] {r['mtime']}  {r['bytes']:>6}B  {r['file']}")
    if not pending:
        print("  （空）")
    print("出站 TO-EXEC  已投:", len(sent))
    for r in sent:
        print(f"  [{r['sha256_16']}] {r['mtime']}  {r['bytes']:>6}B  {r['file']}")
    if not sent:
        print("  （空）")
    print("=" * 62)
    if pending:
        print("处置：核完后 `--done <片段>` 归档；⛔ 不删件")
    return 0


if __name__ == "__main__":
    sys.exit(main())
