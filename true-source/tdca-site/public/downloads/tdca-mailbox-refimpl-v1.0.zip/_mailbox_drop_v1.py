# SPDX-License-Identifier: Apache-2.0
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""信箱投放器（零依赖 · 仅标准库）——投件入夹并生成 17 B 单行大写旁注。

依 TDCA-SPEC-MAILBOX-001 V1.0-FROZEN 与其双后端自测完成件（在册）：
  · 投递＝件 + 同名 .sha256 旁注（17 B，单行，大写，末 0x0A，无 BOM）
  · 旁注值＝整件原始字节 sha256 前 16 位大写（⛔ 件头自报值，防串件）
  · 只投不改件；目标夹不存在即报，⛔ 自建
  · 默认信箱根＝脚本同级 mailbox/（--mailbox-root 可覆盖）

用法：
  python _mailbox_drop_v1.py --file <件路径> --to TO-EXEC|TO-WB|FROM-EXEC|FROM-WB|DONE
  python _mailbox_drop_v1.py --file <件路径> --box <目标夹绝对路径>
  python _mailbox_drop_v1.py --file <件> --to TO-EXEC --dry-run
退出码：0 OK / 1 已有同名异内容（拒覆盖）/ 2 不可得
"""
import argparse
import hashlib
import os
import shutil
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_BOX = os.path.join(SCRIPT_DIR, "mailbox")


def sha16_bytes(b):
    return hashlib.sha256(b).hexdigest().upper()[:16]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", required=True)
    ap.add_argument("--to", default=None, choices=["TO-EXEC", "TO-WB", "FROM-EXEC", "FROM-WB", "DONE"])
    ap.add_argument("--box", default=None, help="目标夹绝对路径（与 --to 二选一）")
    ap.add_argument("--mailbox-root", default=DEFAULT_BOX)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    src = os.path.abspath(a.file)
    if not os.path.isfile(src):
        print("UNKNOWN 读数不可得：源件不存在 %s" % src)
        return 2

    if a.box:
        dst_dir = os.path.abspath(a.box)
    elif a.to:
        dst_dir = os.path.join(a.mailbox_root, a.to)
    else:
        print("UNKNOWN 须给 --to 或 --box")
        return 2

    if not os.path.isdir(dst_dir):
        print("UNKNOWN 目标夹不存在（⛔ 自建）：%s" % dst_dir)
        return 2

    data = open(src, "rb").read()
    h = sha16_bytes(data)
    name = os.path.basename(src)
    dst = os.path.join(dst_dir, name)

    if os.path.exists(dst):
        old = open(dst, "rb").read()
        if sha16_bytes(old) != h:
            print("DIFF 同名已存且内容不同，拒覆盖：%s（旧 %s／新 %s）" % (dst, sha16_bytes(old), h))
            return 1
        print("OK 同名同内容已在位（未重复复制）：%s" % dst)
        state = "present"
    else:
        state = "copied"

    if a.dry_run:
        print("DRY 将投 %s（%d B，%s）→ %s ｜ 旁注 %s" % (name, len(data), h, dst_dir, h))
        return 0

    if state == "copied":
        shutil.copyfile(src, dst)
    side = dst + ".sha256"
    with open(side, "w", encoding="utf-8", newline="\n") as f:
        f.write(h + "\n")

    side_bytes = open(side, "rb").read()
    ok_side = (len(side_bytes) == 17 and side_bytes.endswith(b"\n") and side_bytes[:16].decode().isupper())
    print("OK %s：%s（%d B，sha256_16=%s）｜旁注 %d B 合规=%s"
          % (state, os.path.basename(dst), len(data), h, len(side_bytes), ok_side))
    return 0


if __name__ == "__main__":
    sys.exit(main())
