# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
"""import_json.py：JSON 台账 ⟹ YAML 文本（供使用者回灌自建账本）。

纯标准库：只把 JSON 结构逐字翻译成 YAML 文本（dict/list/str/int/float/bool/None），
⛔ 不做语义校验；导入权威账本请用带 PyYAML 环境的正式通道。
用法：python import_json.py <in.json> [<out.yaml>]
"""
import json
import sys


def _esc(s):
    if s == "":
        return "''"
    if any(c in s for c in ":#{}[]&,*?|-<>=!%@\"'\n") or s != s.strip() or s[0].isdigit() or s[0] in "-?.":
        return json.dumps(s, ensure_ascii=False)
    return s


def dump(node, indent=0):
    pad = "  " * indent
    lines = []
    if isinstance(node, dict):
        if not node:
            return [pad + "{}"]
        for k, v in node.items():
            key = _esc(str(k))
            if isinstance(v, (dict, list)) and v:
                lines.append(f"{pad}{key}:")
                lines.extend(dump(v, indent + 1))
            elif isinstance(v, dict):
                lines.append(f"{pad}{key}: {{}}")
            elif isinstance(v, list):
                lines.append(f"{pad}{key}: []")
            elif v is None:
                lines.append(f"{pad}{key}: null")
            elif isinstance(v, bool):
                lines.append(f"{pad}{key}: {'true' if v else 'false'}")
            else:
                lines.append(f"{pad}{key}: {_esc(str(v)) if isinstance(v, str) else v}")
    elif isinstance(node, list):
        if not node:
            return [pad + "[]"]
        for v in node:
            if isinstance(v, dict) and v:
                items = dump(v, indent + 1)
                lines.append(f"{pad}- {items[0].lstrip()}")
                lines.extend(items[1:])
            elif isinstance(v, list) and v:
                items = dump(v, indent + 1)
                lines.append(f"{pad}-")
                lines.extend(items)
            elif isinstance(v, str):
                lines.append(f"{pad}- {_esc(v)}")
            elif v is None:
                lines.append(f"{pad}- null")
            elif isinstance(v, bool):
                lines.append(f"{pad}- {'true' if v else 'false'}")
            else:
                lines.append(f"{pad}- {v}")
    return lines


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    src = sys.argv[1]
    dst = sys.argv[2] if len(sys.argv) > 2 else src.rsplit(".", 1)[0] + ".yaml"
    doc = json.load(open(src, encoding="utf-8"))
    text = "\n".join(dump(doc)) + "\n"
    with open(dst, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    print("OK", src, "->", dst, len(text.encode("utf-8")), "B")
    return 0


if __name__ == "__main__":
    sys.exit(main())
