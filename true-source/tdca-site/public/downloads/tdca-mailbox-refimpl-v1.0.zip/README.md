# TDCA 信箱协议 refimpl 包（tdca-mailbox-refimpl-v1.0）

## 是什么

`MAILBOX-COLLAB` 参考实现：五件（台账＋认领／扫描／投放／归位）＋ 机验断言集 ＋ JSON→YAML 回灌器。

| 件 | 做什么 |
|---|---|
| `_mailbox_ledger_v1.py` | 信箱常态台账（六态对账）＋ `--ack` 认领（凭据件号＋原件哈希，⛔ 口称即认） |
| `_mailbox_scan.py` | 双向扫描（入站列出／`--done` 归位） |
| `_mailbox_drop_v1.py` | 投放器（旁注 17 B 大写 16 位；dry-run／实投／幂等／拒覆盖／目标夹缺五态） |
| `_l1si159_mailbox_done_v1.py` | 归位器（已核件连旁注挪 DONE，`--move 夹/件名` 可重复） |
| `_mbx_assert_v011.py` | V0.11 断言机验器（合规集＋对抗集，退出 0/1） |
| `import_json.py` | JSON 台账 ⟹ YAML 文本（回灌自建账本） |

## 依赖

**零依赖**：Python ≥ 3.10 纯标准库。台账双后端：`--data-format auto`（有 PyYAML 用 YAML，无则 JSON）／`yaml`／`json`；环境变量 `TDCA_MB_NOYAML=1` 可强制 JSON。

## 怎么跑（一行命令示例）

```bash
python _mailbox_drop_v1.py --file 件.md --to TO-EXEC --dry-run   # 试投
python _mailbox_ledger_v1.py --check                              # 对账（默认信箱根＝脚本同级 mailbox/）
python _mbx_assert_v011.py                                        # 断言自测
```

## 许可

Apache-2.0（见 `LICENSE`）。各件头已标 `SPDX-License-Identifier: Apache-2.0`。
