# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
"""信箱归位器：已核件连旁注挪 DONE（件名不改，不删）。

⭐ 用法：
  python _l1si159_mailbox_done_v1.py --mailbox-root <路径> --move FROM-EXEC/件名 [--move FROM-WB/件名 ...]
    # --move 可重复；件名＝夹内文件名（不含 .sha256，旁注随件自动同挪）
    # 共夹防重名：冲突时按来源夹加 EXEC-/WB- 前缀
  [--list]            # 只打印夹现状，不挪
⭐ 默认信箱根＝脚本同级 mailbox/（--mailbox-root 可覆盖）。
"""
import argparse
import os
import shutil

SIDE_OF = {"FROM-EXEC": "EXEC", "FROM-WB": "WB", "TO-EXEC": "EXEC", "TO-WB": "WB"}


def move_items(MB, moves):
    DONE = os.path.join(MB, "DONE")
    os.makedirs(DONE, exist_ok=True)
    for rel in moves:
        box, _, name = rel.partition("/")
        assert box and name, "须形如 FROM-EXEC/件名"
        side = SIDE_OF.get(box, "EXEC")
        src = os.path.join(MB, box, name)
        assert os.path.exists(src), src
        for p in (src, src + ".sha256"):
            if not os.path.exists(p):
                continue
            base = os.path.basename(p)
            dst = os.path.join(DONE, base)
            if os.path.exists(dst):
                dst = os.path.join(DONE, f"{side}-{base}")
            shutil.move(p, dst)
            print("MOVED", rel if p == src else rel + ".sha256", "->", os.path.basename(dst))


def census(MB):
    print("--- 夹现状 ---")
    for d in sorted(os.listdir(MB)):
        p = os.path.join(MB, d)
        if os.path.isdir(p):
            print(d, len([f for f in os.listdir(p) if os.path.isfile(os.path.join(p, f))]))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mailbox-root", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "mailbox"),
                    help="信箱根（默认脚本同级 mailbox/）")
    ap.add_argument("--move", action="append", metavar="夹/件名", help="归位一件（可重复）")
    ap.add_argument("--list", action="store_true", help="只打印夹现状")
    a = ap.parse_args()
    MB = os.path.abspath(a.mailbox_root)
    if a.move:
        move_items(MB, a.move)
    if a.move or a.list:
        census(MB)
    if not a.move and not a.list:
        ap.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
