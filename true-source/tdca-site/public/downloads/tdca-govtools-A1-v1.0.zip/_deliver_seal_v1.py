# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
"""交付前机验与首行封签（判据 C-01/C-02/C-03/C-04/C-13）

用法：
  python _deliver_seal_v1.py --check <件路径> [<件路径> ...]      # 只读机验
  python _deliver_seal_v1.py --seal  <件路径> [<件路径> ...]      # 先机验，再对未封签件回填首行与旁注
  可加 --external：额外按对外纪律扫内部编号式样

末行固定输出 DELIVER_VERDICT=PASS 或 DELIVER_VERDICT=FAIL(n)。
安全默认：--check 只读；--seal 只对「首行为 MAIL 且 sha256_16 非 16 位大写十六进制」之件回填，
⛔ 不回改已封签件；⛔ 旁注与实物不符时不覆盖（报 FAIL 交人）。
"""
import argparse
import hashlib
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ZERO = "sha256_16=0000000000000000"
FIELD_RE = re.compile(r"sha256_16=([0-9A-Za-z<]{0,64})")
HEX16_RE = re.compile(r"^[0-9A-F]{16}$")
NAME_MAX = 110

# 内部编号式样（仅 --external 时启用；按在册二分口径：这些算内部编号）
INTERNAL_ID = [
    ("GSEQ", re.compile(r"GSEQ-\d{3,}")),
    ("L1SI", re.compile(r"L1SI[-_]?\d{2,}", re.I)),
    ("NCA-日期", re.compile(r"NCA[-_]20\d{6}")),
    ("T-号", re.compile(r"\bT-\d{2,3}\b")),
    ("内部 ID", re.compile(r"\bID\d{1,3}\b")),
]

# C-18 终态字样（同行含否定语境者不计）
FINAL_TERMS = re.compile(r"(最终版|终态|定稿不再变|final\s+and\s+frozen)", re.I)
NEGATION = ("⛔", "不得", "不写", "禁止", "勿", "不许", "⛔", "不应")

# 凭据八形态（只报计数，不回显命中内容）
CRED = [
    ("gitee/github 令牌前缀", re.compile(r"\b(?:ghp_|gho_|github_pat_)[A-Za-z0-9_]{10,}")),
    ("通用 sk 键", re.compile(r"\bsk-[A-Za-z0-9]{16,}")),
    ("云商访问键", re.compile(r"\bAKIA[0-9A-Z]{12,}")),
    ("私钥头", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("Slack 令牌", re.compile(r"\bxox[bps]-[A-Za-z0-9-]{10,}")),
    ("JWT 三段", re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}")),
    ("口令赋值", re.compile(r"(?i)\b(?:password|passwd|pwd|口令|密码)\s*[:=]\s*\S{6,}")),
    ("长十六进制串", re.compile(r"\b[0-9a-fA-F]{64}\b")),
]


def sha16(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest().upper()[:16]


def read_text(path):
    with open(path, "rb") as f:
        raw = f.read()
    return raw, raw.decode("utf-8")


def zeroed_sha16(text, field_value):
    """零占位法：把首行该字段换成 16 个 0 后取整件哈希前 16 位。"""
    return hashlib.sha256(
        text.replace("sha256_16=" + field_value, ZERO).encode("utf-8")
    ).hexdigest().upper()[:16]


def zeroed_sha16_bare(text, field_value):
    """零占位法（容忍形态：首行裸值行 ＋ 第二行 MAIL 头同值）。

    L1-SI-191 批 6 实测发现：有件把自证值单列为首行裸值、MAIL 头退居第二行，
    原实现只认 `sha256_16=` 前缀 ⟹ 只置零 MAIL 头一处、裸值行不动 ⟹ 复算不符。
    本条把「首行裸值」与「全文 sha256_16=该值」同置零，与执行侧「两处同置零」口径一致。
    """
    t = text.replace("sha256_16=" + field_value, ZERO)
    head, sep, rest = t.partition("\n")
    if head.strip() == field_value:
        head = "0" * 16
    return hashlib.sha256((head + sep + rest).encode("utf-8")).hexdigest().upper()[:16]


def check_one(path, external=False):
    """返回 (状态条列表, 失败计数)；状态条形如 (级别, 码, 说明)。"""
    out, fails = [], 0

    def add(level, code, msg):
        nonlocal fails
        out.append((level, code, msg))
        if level == "FAIL":
            fails += 1

    name = os.path.basename(path)
    if not os.path.exists(path):
        add("FAIL", "C-00", "件不存在")
        return out, fails

    # C-02 件名长度
    add("PASS" if len(name) <= NAME_MAX else "FAIL", "C-02",
        f"件名 {len(name)} 字符" + ("" if len(name) <= NAME_MAX else f" 超 {NAME_MAX}"))

    raw, text = read_text(path)
    # C-03 编码与行尾
    bom = raw.startswith(b"\xef\xbb\xbf")
    cr = b"\r" in raw
    add("PASS" if not bom and not cr else "FAIL", "C-03",
        ("UTF-8 无 BOM、LF" if not bom and not cr else
         f"编码/行尾不符（BOM={bom} CR={cr}）"))

    first = text.split("\n", 1)[0]
    second = text.split("\n")[1] if text.count("\n") >= 1 else ""
    bare_sealed = bool(HEX16_RE.match(first.strip())) and second.startswith("MAIL")
    if not first.startswith("MAIL") and not bare_sealed:
        add("SKIP", "C-01", "内部件（无 MAIL 首行），首行封签不适用")
        add("SKIP", "C-04", "内部件不投信箱，旁注不适用")
    else:
        if bare_sealed:
            val = first.strip()
            add("PASS" if zeroed_sha16_bare(text, val) == val else "FAIL", "C-01",
                "零占位法（容忍形态：首行裸值＋次行 MAIL）" +
                ("可复算" if zeroed_sha16_bare(text, val) == val else "复算不符"))
            add("SKIP", "C-01", "形态建议：自证值宜并入首行 MAIL 头，勿单列裸值行")
        else:
            m = FIELD_RE.search(first)
            val = m.group(1) if m else ""
            if not HEX16_RE.match(val):
                add("FAIL", "C-01", "首行 sha256_16 非 16 位大写十六进制")
            else:
                add("PASS" if zeroed_sha16(text, val) == val else "FAIL", "C-01",
                    "零占位法" + ("可复算" if zeroed_sha16(text, val) == val else "复算不符"))
        side = path + ".sha256"
        if not os.path.exists(side):
            add("FAIL", "C-04", "缺旁注 .sha256")
        else:
            sv = open(side, "rb").read()
            s = sv.decode("utf-8", "replace").strip()
            real = sha16(path)
            ok = (len(sv) == 17 and s == real)
            add("PASS" if ok else "FAIL", "C-04",
                f"旁注 {len(sv)}B 值" + ("符" if s == real else f"不符（旁注 {s[:8]}… 实物 {real[:8]}…）"))

    # C-13 凭据（恒查）+ 内部编号（仅对外件）
    hits = 0
    for _, rx in CRED:
        hits += len(rx.findall(text))
    add("PASS" if hits == 0 else "FAIL", "C-13", f"凭据形态命中 {hits}")
    if external:
        idhits = 0
        for _, rx in INTERNAL_ID:
            idhits += len(rx.findall(text))
        add("PASS" if idhits == 0 else "FAIL", "C-13外", f"内部编号式样命中 {idhits}")

    # C-18 终态字样（否定语境豁免：整行否定词 或 匹配串前两字为 无/非/没）
    fin = []
    for ln in text.split("\n"):
        if any(n in ln for n in NEGATION):
            continue
        for m in FINAL_TERMS.finditer(ln):
            pre = ln[max(0, m.start() - 2):m.start()]
            if not any(c in pre for c in ("无", "非", "没")):
                fin.append(ln.strip()[:40])
                break
    add("PASS" if not fin else "FAIL", "C-18",
        "无终态字样" if not fin else f"终态字样 {len(fin)} 行（如：{fin[0]}…）")
    return out, fails


def seal_one(path):
    """对未封签的投递件回填首行自哈希与旁注；幂等，不覆盖已符旁注。"""
    raw, text = read_text(path)
    first = text.split("\n", 1)[0]
    if not first.startswith("MAIL"):
        return "SKIP", "内部件，不封签"
    m = FIELD_RE.search(first)
    val = m.group(1) if m else ""
    side = path + ".sha256"
    if HEX16_RE.match(val) and os.path.exists(side) and open(side, "rb").read().decode(
            "utf-8", "replace").strip() == sha16(path):
        return "KEEP", "已封签且旁注符，未改动"
    if HEX16_RE.match(val) and os.path.exists(side):
        return "REFUSE", "已封签但旁注不符，须人工判定（不回改）"
    if not FIELD_RE.search(first):
        return "REFUSE", "首行无 sha256_16 字段，须人工补字段"
    # 回填：先以零占位算，再替换
    base = text.replace("sha256_16=" + val, "sha256_16=" + "0" * 16)
    h0 = hashlib.sha256(base.encode("utf-8")).hexdigest().upper()[:16]
    with open(path, "wb") as f:
        f.write(base.replace(ZERO, "sha256_16=" + h0).encode("utf-8"))
    with open(side, "w", encoding="utf-8", newline="\n") as f:
        f.write(sha16(path) + "\n")
    return "SEALED", f"字段={h0} 旁注={sha16(path)}"


def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("--check", nargs="*", default=None)
    ap.add_argument("--seal", nargs="*", default=None)
    ap.add_argument("--external", action="store_true")
    ap.add_argument("--require-mail", action="store_true")
    a = ap.parse_args()

    targets = a.check if a.check is not None else a.seal
    if not targets:
        print("用法: _deliver_seal_v1.py --check|--seal <件路径> [...] [--external]")
        print("DELIVER_VERDICT=SKIP(无输入)")
        return 0

    total_fail = 0
    for p in targets:
        print("—", os.path.basename(p))
        rows, fails = check_one(p, a.external)
        # v1.2：投递件须 MAIL 起首（--require-mail）——非 MAIL 首行之投递件应判 FAIL，
        # ⛔ 沿用 C-01/C-04 之 SKIP（SKIP 只对真正的内部件成立）。
        if a.require_mail:
            try:
                _first = open(p, encoding="utf-8").readline()
            except Exception:
                _first = ""
            if not _first.startswith("MAIL"):
                rows.append(("FAIL", "C-05", "投递件首行须 MAIL 起首（现为非 MAIL）"))
                fails += 1
        for level, code, msg in rows:
            mark = {"PASS": "✅", "FAIL": "❌", "SKIP": "·"}[level]
            print(f"   {mark} {code} {msg}")
        total_fail += fails
        # v1.1：待封签件（首行全 0 且缺旁注）应允许直接回填，
        # ⛔ 不因 C-01/C-04 之"必然失败"而拒绝封签。
        _pending_seal = {c for lv, c, _ in rows if lv == "FAIL"} <= {"C-01", "C-04"}
        if (fails == 0 or (_pending_seal and rows and any(r[1] == "C-01" for r in rows))) and a.seal is not None:
            state, note = seal_one(p)
            print(f"   {'🔏' if state == 'SEALED' else '·'} 封签 {state}：{note}")

    print(f"DELIVER_VERDICT={'PASS' if total_fail == 0 else f'FAIL({total_fail})'}")
    return 0 if total_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
