# SPDX-License-Identifier: Apache-2.0
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""智库侧日常运维 v1（程序化·零 token）——一条命令跑完当日例行核查并出日报。

跑什么（按序，任何一步失败不中断，最后汇总）：
  1. 链验        _nca_chain_verify_v1.py --quiet      → VERDICT
  2. 双库一致    工作区 registry ↔ 桌面归档 registry    → MD5 同否
  3. 信箱对账    _mailbox_ledger_v1.py --check         → 待处理/四零立
  4. 日锚        _daily_anchor_v1.py（--seal 见 mode）  → 当日锚值/链
  5. 归档同步    _sync_workspace_archive_v2.py（幂等）  → 复制数/未变
  6. 体量        件数/records/max/gap 快照

模式：
  --mode morning（默认）链验+双库+信箱+日锚(不封)+同步+体量
  --mode evening        同上，日锚以 --amend --seal 收口（日末定稿）

产出：
  .tdca-nca/reports/ops_daily/_OPS-DAILY-<YYYYMMDD>.md   （morning 覆盖、evening 追加终版）
  .tdca-nca/reports/ops_daily/_OPS-LOG.txt               （每次一行）
退出码：0 全绿／1 有差／2 不可得
"""
import argparse
import hashlib
import os
import subprocess
import sys
from datetime import datetime, timezone, timedelta

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

CST = timezone(timedelta(hours=8))
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
SCRIPTS = os.path.join(ROOT, ".tdca-nca", "scripts")
OUTDIR = os.path.join(ROOT, ".tdca-nca", "reports", "ops_daily")
PY = sys.executable


def run(args, timeout=600):
    try:
        p = subprocess.run([PY] + args, cwd=ROOT, capture_output=True, timeout=timeout)
        out = (p.stdout or b"").decode("utf-8", errors="replace")
        err = (p.stderr or b"").decode("utf-8", errors="replace")
        return p.returncode, out, err
    except Exception as e:
        return 2, "", repr(e)


def md5(path):
    with open(path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest().upper()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["morning", "evening"], default="morning")
    a = ap.parse_args()
    now = datetime.now(CST)
    date = now.strftime("%Y%m%d")
    stamp = now.strftime("%Y-%m-%dT%H:%M:%S+08:00")
    rows = []
    verdict = 0

    # 1 链验
    rc, out, err = run([os.path.join(SCRIPTS, "_nca_chain_verify_v1.py"), "--quiet"])
    line = next((l for l in out.splitlines() if "VERDICT" in l), "").strip()
    rows.append(("链验", "OK" if (rc == 0 and "PASS" in line) else "DIFF", line or err[-200:] or "rc=%d" % rc))
    if rc != 0:
        verdict = max(verdict, 1)

    # 2 双库一致
    ws = os.path.join(ROOT, ".tdca-nca", "NCA-REGISTRY.yaml")
    dk = os.path.join(os.path.expanduser("~"), "Desktop", "TDCA归档文件夹", ".tdca-nca", "NCA-REGISTRY.yaml")
    try:
        same = md5(ws) == md5(dk)
        rows.append(("双库一致", "OK" if same else "DIFF", md5(ws) if same else "%s ≠ %s" % (md5(ws), md5(dk))))
        if not same:
            verdict = max(verdict, 1)
    except Exception as e:
        rows.append(("双库一致", "UNKNOWN", repr(e)))
        verdict = max(verdict, 2)

    # 3 信箱对账
    rc, out, err = run([os.path.join(SCRIPTS, "_mailbox_ledger_v1.py"), "--check"])
    pend = [l for l in out.splitlines() if "待处理" in l]
    four = [l for l in out.splitlines() if "盘上有台账无" in l]
    ok3 = rc == 0 and (not pend or "待处理（NEW/PENDING）0" in "".join(pend) or "：0 件" in "".join(pend))
    rows.append(("信箱对账", "OK" if ok3 else "DIFF", (pend[0].strip() if pend else "无输出") + "｜" + (four[0].strip() if four else "")))
    if not ok3:
        verdict = max(verdict, 1)

    # 4 日锚
    anchor_args = [os.path.join(SCRIPTS, "_daily_anchor_v1.py")]
    if a.mode == "evening":
        anchor_args += ["--amend", "--seal"]
    rc, out, err = run(anchor_args)
    rows.append(("日锚", "OK" if rc == 0 else ("DIFF" if rc == 1 else "UNKNOWN"), (out.strip().splitlines() or [""])[-1][:160]))
    if rc != 0:
        verdict = max(verdict, 1 if rc == 1 else 2)

    # 5 归档同步（幂等）
    rc, out, err = run([os.path.join(SCRIPTS, "_sync_workspace_archive_v2.py")])
    tail = [l for l in out.splitlines() if "SYNCED" in l or "复制" in l]
    rows.append(("归档同步", "OK" if rc == 0 else "DIFF", (tail[-1].strip() if tail else "无输出")))
    if rc != 0:
        verdict = max(verdict, 1)

    # 6 体量
    try:
        import yaml
        reg = yaml.safe_load(open(ws, encoding="utf-8"))
        nums = [int(str(r["gseq"])[5:]) for r in reg["records"]]
        rows.append(("体量", "OK", "records=%d max=GSEQ-%d gap=%d" % (len(nums), max(nums), max(nums) - len(nums))))
    except Exception as e:
        rows.append(("体量", "UNKNOWN", repr(e)))
        verdict = max(verdict, 2)

    names = {"0": "OK", "1": "DIFF", "2": "UNKNOWN"}
    lines = []
    lines.append("# 智库侧运维日报 %s（%s）" % (date, a.mode))
    lines.append("")
    lines.append("> 生成时刻：%s ｜ 判定：**%s**（退出码 %d）" % (stamp, names[str(verdict)], verdict))
    lines.append("")
    lines.append("| # | 项 | 判 | 读数 |")
    lines.append("|---|---|---|---|")
    for i, (k, v, d) in enumerate(rows, 1):
        lines.append("| %d | %s | %s | %s |" % (i, k, v, str(d).replace("|", "/")))
    lines.append("")
    body = "\n".join(lines) + "\n"

    os.makedirs(OUTDIR, exist_ok=True)
    f = os.path.join(OUTDIR, "_OPS-DAILY-%s.md" % date)
    mode = "w" if (a.mode == "morning" or not os.path.exists(f)) else "a"
    with open(f, mode, encoding="utf-8", newline="\n") as fh:
        fh.write(("" if mode == "w" else "\n---\n\n") + body)
    with open(os.path.join(OUTDIR, "_OPS-LOG.txt"), "a", encoding="utf-8", newline="\n") as fh:
        fh.write("%s %s %s " % (stamp, a.mode, names[str(verdict)]) +
                 " ".join("%s=%s" % (k, v) for k, v, _ in rows) + "\n")

    print(body)
    print("REPORT=%s" % f)
    return verdict


if __name__ == "__main__":
    sys.exit(main())
