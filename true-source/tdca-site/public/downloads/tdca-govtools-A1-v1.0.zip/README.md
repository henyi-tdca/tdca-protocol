# TDCA 治理工具集 A-1（tdca-govtools-A1）

## 是什么

TDCA 治理侧七件单文件工具，覆盖 **核／查／记／签** 四类，彼此不重叠：

| 件 | 做什么 |
|---|---|
| `_nca_chain_verify_v1.py` | 链验：链完整性、断链／重号检出（只读） |
| `_nca_discipline_check_v5.py` | 纪律核：在册铁律机验（只读） |
| `_mailbox_ledger_v1.py` | 信箱台账：对账／认领／四零立 |
| `_daily_patrol_v1.py` | 日常巡检：账本／信箱／站点 |
| `_weekly_deep_check_v1.py` | 周度深核：件自哈希／双库件面／收录 |
| `_ops_daily_v1.py` | 运维日报：六项核一条命令 |
| `_deliver_seal_v1.py` | 交付封签：件头自哈希（乙式）／旁注 |

## 依赖

Python ≥ 3.10，仅标准库 ＋ PyYAML（`pip install pyyaml`）。

## 怎么跑（一行命令示例）

```bash
python _nca_chain_verify_v1.py --help        # 链验
python _nca_discipline_check_v5.py --help    # 纪律核
python _mailbox_ledger_v1.py --help          # 信箱台账
python _daily_patrol_v1.py --help            # 日常巡检
python _weekly_deep_check_v1.py --help       # 周度深核
python _ops_daily_v1.py --help               # 运维日报
python _deliver_seal_v1.py --help            # 交付封签
```

各件 `--help` 见自有参数；巡检／深核／日报类件面向本侧固定目录布局，外置环境请以 `--help` 与件头说明为准。

## 许可

Apache-2.0（见 `LICENSE`）。各件头已标 `SPDX-License-Identifier: Apache-2.0`。
