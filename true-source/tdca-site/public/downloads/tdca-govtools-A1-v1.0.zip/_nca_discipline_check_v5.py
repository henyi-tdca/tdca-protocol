# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
"""NCA 编号与归档纪律 · 真校验器 **v5**（2026-09-19 · L1-SI-058）

⭐ **工件来处（照制度—工件关系口径：工件必有来处，必因制度件产生）**：
  主制度件：`TDCA-NCA-COMPILED-001`（NCA 制度合一版）—— §四.2 义务块（裁定 R-2）＋ §十五 常态校验器。
  配套裁定：`TDCA-RULING-NCA-COMPILED-001-001`（四项裁定）＋ 本框裁定落地件 `TDCA-RULING-L1SI<n>-001`（U-4 处置）。
  ⚠️ 本工件为**上述制度件之专属工件**（常态校验器族 v1→v2→v3→v4→v5 之最新版）。

⭐ 新建 v5，⛔ **不编辑 v1~v4**（四版留档，追加制）。
⭐ v5 只改一处（照只读侧 P3-COMPILED-001 第二轮回报之新发现 **A-10** ＋ 本侧实测复现）：
  **C2 前缀对称** —— v4 之 `id_matches` 只认「件内 ID 无 `NCA-` 前缀」之写法；而他侧域（WB／KW／ECOACT）
  件内 `nca_id` **普遍带 `NCA-` 前缀** ⟹ 前缀不对称致 C2 **系统性误报**（只读侧域 113/114）。
  ⭐ v5 改为 **两侧写法皆认**（件内带、不带 `NCA-` 前缀均可）—— ⚠️ 域内分治下⛔ 不预设单一写法。
⭐ 保留 v4 两处修正（照只读侧 SLIMMING-P234-001 补注件 A-7／A-8 ＋ 本侧实测）：
  1. **后缀剥离通用化**（修 A-7）：⛔ 不依赖后缀清单（v3 之 `-(D|W)$` 硬编码在他域全数误报）。
  2. **件枚举递归化**（修 A-8）：默认 `os.walk`，⭐ 保留 `--no-recurse` 供旧口径对比，⭐ 输出明示口径。
⭐ 其余保留 v3 之修正：C9 义务块六键校验（裁定 R-2 落地物）／`chain_id` 在必需字段内（13 项）／
  C6 不计入 `NCA-REGISTRY.yaml` 自身／域可参数化 `--nca-dir`。
⭐ 口径纪律：存量照「存量另议」—— **只报不删、不回改**；存量 FAIL **不阻断新件**。
运行：python _nca_discipline_check_v5.py [--nca-dir <路径>] [--no-recurse] [--quiet] [--exit-zero]
末行：VERDICT=PASS 或 VERDICT=FAIL
"""
import argparse
import hashlib
import os
import re
import sys
from datetime import datetime, timezone

import yaml

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

WS_NCA_DEFAULT = r"C:\Users\22850\AppData\Roaming\reasonix\global-workspace\.tdca-nca"

FNAME_RE = re.compile(r"^NCA-(?P<side>[A-Z0-9\-]+?)-(?P<date>\d{8})-(?P<seq>\d{3})(?P<suffix>-[A-Za-z0-9\-]+)?\.yaml$")
REQUIRED_TITLECASE = ["NCA-ID", "Function-Call-ID", "Operation-Type", "Operator", "Timestamp",
                      "Scope", "Pre-State", "Post-State", "Config-Right-Token", "Audit-Trail",
                      "Negative-Space-Check"]
REQUIRED_SNAKE = ["nca_id", "side", "timestamp", "chain_space", "chain_id", "chain_ref", "prev_nca",
                  "operation_type", "actor", "artifacts", "data_provenance", "profit_sharing", "compliance"]
REQUIRED_OBLIGATIONS = ["function_call_id", "state_hashes", "config_right",
                        "audit_trail", "human_signature", "negative_space_check"]


def md5(p):
    with open(p, "rb") as f:
        return hashlib.md5(f.read()).hexdigest().upper()


def list_nca(root, recurse):
    """列 NCA 件：返回 [(相对路径, basename)]。⭐ recurse=True 用 os.walk（修 A-8）。"""
    out = []
    if recurse:
        for dirpath, _dirs, files in os.walk(root):
            for f in files:
                if f.startswith("NCA-") and f.endswith(".yaml") and f != "NCA-REGISTRY.yaml":
                    out.append((os.path.relpath(os.path.join(dirpath, f), root), f))
    else:
        for f in os.listdir(root):
            if f.startswith("NCA-") and f.endswith(".yaml") and f != "NCA-REGISTRY.yaml":
                out.append((f, f))
    return sorted(out)


def id_matches(fn, inner):
    """⭐ 后缀剥离通用化（修 A-7）＋ ⭐ 前缀对称（修 A-10）：不依赖后缀清单。

    件名核心 = 文件名去 `NCA-` 前缀与 `.yaml`；件内 ID（⭐ **可带、可不带 `NCA-` 前缀**）应等于核心，
    或为核心之**前缀且紧随一个 `-`**（即件名带任意后缀）。
    ⚠️ A-10 由来：v4 只认「件内 ID 无 `NCA-` 前缀」之写法，而他侧域（WB／KW／ECOACT）件内普遍带前缀
    ⟹ 前缀不对称致 C2 系统性误报；v5 两侧写法皆认（域内分治下不预设单一写法）。
    """
    core = fn[len("NCA-"):-len(".yaml")]
    s = str(inner)
    s_core = s[len("NCA-"):] if s.startswith("NCA-") else s
    return s_core == core or core.startswith(s_core + "-")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--nca-dir", default=WS_NCA_DEFAULT)
    ap.add_argument("--no-recurse", action="store_true", help="单层枚举（v3 旧口径，仅供对比）")
    ap.add_argument("--quiet", action="store_true")
    ap.add_argument("--exit-zero", action="store_true")
    args = ap.parse_args()

    recurse = not args.no_recurse
    nca_dir = args.nca_dir
    problems = {k: [] for k in ("C1", "C1X", "C2", "C3", "C4", "C5", "C6", "C7", "C9")}
    err_types = {}
    stat = {"total": 0, "marker": 0, "titlecase": 0, "snake": 0, "obligations": 0, "subdir": 0, "suffix_ok": 0}

    entries = list_nca(nca_dir, recurse)
    files = [bn for _rel, bn in entries]
    stat["total"] = len(files)
    stat["subdir"] = sum(1 for rel, _bn in entries if os.sep in rel or "/" in rel)

    reg_path = os.path.join(nca_dir, "NCA-REGISTRY.yaml")
    reg = yaml.safe_load(open(reg_path, encoding="utf-8")) if os.path.isfile(reg_path) else {}
    recs = reg.get("records", [])
    registered = set()
    for r in recs:
        for f in r.get("files", []) or []:
            registered.add(os.path.basename(str(f)))

    for rel, bn in entries:
        path = os.path.join(nca_dir, rel)
        m = FNAME_RE.match(bn)
        if not m:
            if bn in registered:
                continue
            problems["C1X"].append(f"{rel} (专属 ID 且索引无登记)")
            continue
        try:
            with open(path, encoding="utf-8") as f:
                doc = yaml.safe_load(f)
        except Exception as e:
            err_types[type(e).__name__] = err_types.get(type(e).__name__, 0) + 1
            problems["C3"].append(f"{rel} ({type(e).__name__})")
            continue
        if not isinstance(doc, dict):
            problems["C3"].append(f"{rel} (非映射)")
            continue

        inner = doc.get("NCA-ID") or doc.get("nca_id")
        core = bn[len("NCA-"):-len(".yaml")]
        if inner is None:
            problems["C2"].append(f"{rel} (无 NCA-ID/nca_id)")
        elif id_matches(bn, inner):
            if str(inner) != core:
                stat["suffix_ok"] += 1
        else:
            problems["C2"].append(f"{rel} (件内={inner})")

        has_tc = all(k in doc for k in REQUIRED_TITLECASE)
        has_sn = all(k in doc for k in REQUIRED_SNAKE)
        if has_tc:
            stat["titlecase"] += 1
        elif has_sn:
            stat["snake"] += 1
        else:
            miss_sn = [k for k in REQUIRED_SNAKE if k not in doc]
            miss_tc = [k for k in REQUIRED_TITLECASE if k not in doc]
            problems["C4"].append(f"{rel} (缺 TitleCase {len(miss_tc)}｜缺 snake {len(miss_sn)}: {','.join(miss_sn[:4])})")

        obl = doc.get("obligations")
        if isinstance(obl, dict) and all(k in obl for k in REQUIRED_OBLIGATIONS):
            stat["obligations"] += 1
        else:
            problems["C9"].append(f"{rel} (无义务块或六键不齐)")

        if "Generated-By" in doc:
            stat["marker"] += 1

    nums = sorted(int(r["gseq"][5:]) for r in recs if str(r.get("gseq", ""))[5:].isdigit())
    if nums:
        dup = sorted({n for n in nums if nums.count(n) > 1})
        gaps = sorted(set(range(1, max(nums) + 1)) - set(nums))
        if len(recs) != len(nums) or recs[-1]["gseq"] != f"GSEQ-{max(nums)}":
            problems["C5"].append(f"records={len(recs)} vs 数字项={len(nums)}；末条={recs[-1].get('gseq')}")
        if dup:
            problems["C5"].append(f"重复 GSEQ：{dup[:10]}（共 {len(dup)}）")
        if gaps:
            problems["C5"].append(f"GSEQ 缺口：{gaps[:10]}（共 {len(gaps)}）")

    by_day = {}
    for _rel, bn in entries:
        m = FNAME_RE.match(bn)
        if m:
            by_day.setdefault((m.group("side"), m.group("date")), []).append(int(m.group("seq")))
    for (side, day), seqs in sorted(by_day.items()):
        if seqs and max(seqs) != len(seqs):
            problems["C7"].append(f"{side}-{day}: 最大序号 {max(seqs)} ≠ 件数 {len(seqs)}（缺口／双版本）")

    desk_nca = os.path.join(os.path.expanduser(r"~\Desktop\TDCA归档文件夹"), ".tdca-nca")
    if os.path.isdir(desk_nca):
        a = md5(reg_path) if os.path.isfile(reg_path) else "n/a"
        dpath = os.path.join(desk_nca, "NCA-REGISTRY.yaml")
        d = md5(dpath) if os.path.isfile(dpath) else "n/a"
        if a != d:
            problems["C6"].append(f"registry MD5 不一致 ws={a} desk={d}")
        desk_set = set(bn for _rel, bn in list_nca(desk_nca, recurse))
        only_ws = sorted(set(files) - desk_set)
        only_desk = sorted(desk_set - set(files))
        if only_ws:
            problems["C6"].append(f"仅本域有 {len(only_ws)} 件：{only_ws[:5]}")
        if only_desk:
            problems["C6"].append(f"仅归档库有 {len(only_desk)} 件：{only_desk[:5]}")
    else:
        problems["C6"].append(f"归档库不存在：{desk_nca}")

    failed = [k for k, v in problems.items() if v]
    print(f"=== NCA 纪律校验 v5 === {datetime.now(timezone.utc).astimezone().strftime('%Y-%m-%dT%H:%M:%S%z')}")
    print(f"域：{nca_dir}")
    print(f"口径：{'递归（含子目录）' if recurse else '单层（--no-recurse）'}")
    print(f"扫描 {stat['total']} 件（其中子目录 {stat['subdir']}）｜TitleCase {stat['titlecase']}｜snake {stat['snake']}｜"
          f"义务块齐备 {stat['obligations']}｜带后缀件通过 {stat['suffix_ok']}｜marker {stat['marker']}（只报）")
    if err_types:
        print("不可解析错型：" + "；".join(f"{k}={v}" for k, v in sorted(err_types.items(), key=lambda x: -x[1])))
    for k in ("C1", "C1X", "C2", "C3", "C4", "C5", "C6", "C7", "C9"):
        v = problems[k]
        print(f"[{k}] {'FAIL' if v else 'PASS'} ({len(v)})")
        if v and not args.quiet:
            for item in v[:6]:
                print("    - " + item)
            if len(v) > 6:
                print(f"    ... 共 {len(v)} 项")
    print("C9 说明：存量件无义务块系历史状态（祖父条款：只报不删、不回改）；新件缺失即 T-2 不过。")
    print(f"FAIL 类：{failed if failed else '无'}")
    print(f"VERDICT={'FAIL' if failed else 'PASS'}")
    return 0 if (args.exit_zero or not failed) else 1


if __name__ == "__main__":
    sys.exit(main())
