# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
r"""NCA 台账 **链验器 v1**（只读 · 2026-09-27 · L1-SI-084）

⭐ 依据：**TDCA-NCA-STD-001 V1.1**（GSEQ-<n>）—— 链语义取自其既有字段，⛔ 不另起数学定义：
    `chain_id`（本侧自链号）／`prev_nca`（本链内前一件 nca_id，链首 `GENESIS`）／`sha256_16`（sha256 前 16 位·大写）。
⭐ 检项（四关，逐条 record）：
    L-1 `chain_id` == 该 record 之 `gseq`
    L-2 `prev_nca` == 上一条**带链** record 之 `nca_id`（链首须为 `GENESIS`）
    L-3 `self_sha256_16` == 该 record 所指件之实测 sha256 前 16 位
    L-4 编号连续（无重号；空号如实列举，⛔ 不判 FAIL——空号系在册状态）
⭐ 口径纪律：⛔ **只读**（永不写回）；⛔ 链起点之前为**未链历史段**（祖父条款），**只报不计 FAIL**。
⭐ 运行：python _nca_chain_verify_v1.py [--nca-dir <路径>] [--quiet]
⭐ 末行：VERDICT=PASS 或 VERDICT=FAIL 或 VERDICT=NO-CHAIN（尚无链起点）
"""
import argparse
import collections
import hashlib
import os
import sys

import yaml

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

WS = r"C:\Users\22850\AppData\Roaming\reasonix\global-workspace"
NCA_DEFAULT = os.path.join(WS, ".tdca-nca")


def sha16(p):
    with open(p, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest().upper()[:16]


def locate(ws_nca, ws, name):
    p = os.path.join(ws_nca, name)
    if os.path.isfile(p):
        return p
    p = os.path.join(ws, name)
    return p if os.path.isfile(p) else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--nca-dir", default=NCA_DEFAULT)
    ap.add_argument("--ws", default=WS)
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    reg_path = os.path.join(args.nca_dir, "NCA-REGISTRY.yaml")
    reg = yaml.safe_load(open(reg_path, encoding="utf-8"))
    recs = reg.get("records", [])
    meta = reg.get("registry_meta", {}) or {}
    start = meta.get("chain_start_gseq")

    print(f"=== NCA 链验器 v1（只读）===")
    print(f"域：{args.nca_dir}")
    print(f"records：{len(recs)}｜链起点：{start or '（无，未链段）'}｜chain_note：{meta.get('chain_note', 'n/a')}")

    if not start:
        print("统计：未链历史段 " + str(len(recs)) + " 条（祖父条款·⛔ 不回改）")
        print("VERDICT=NO-CHAIN")
        return 0

    idx = [i for i, r in enumerate(recs) if r.get("gseq") == start]
    assert idx, f"链起点 {start} 不在 records 中"
    i0 = idx[0]
    fails = {"L-1": [], "L-2": [], "L-3": []}
    prev_nca = None
    n_ok = 0
    for r in recs[i0:]:
        g = r.get("gseq")
        cid, pn, sh = r.get("chain_id"), r.get("prev_nca"), r.get("self_sha256_16")
        if cid != g:
            fails["L-1"].append(f"{g} (chain_id={cid})")
        expect = "GENESIS" if prev_nca is None else prev_nca
        if pn != expect:
            fails["L-2"].append(f"{g} (prev_nca={pn} 期望 {expect})")
        f0 = (r.get("files") or [None])[0]
        p = locate(args.nca_dir, args.ws, f0) if f0 else None
        if p is None:
            fails["L-3"].append(f"{g} (件不可定位: {f0})")
        elif sh is None or sha16(p) != sh:
            fails["L-3"].append(f"{g} (记录 {sh} 实测 {sha16(p)})")
        prev_nca = r.get("nca_id")
        n_ok += 1

    nums = [int(x["gseq"][5:]) for x in recs if str(x.get("gseq", ""))[5:].isdigit()]
    cnt = collections.Counter(nums)
    dups = sorted({k for k, v in cnt.items() if v > 1})
    gaps = sorted(set(range(1, max(nums) + 1)) - set(nums)) if nums else []
    print(f"统计：未链历史段 {i0} 条｜带链段 {n_ok} 条｜重号 {dups or '无'}｜空号 {gaps or '无'}（⛔ 空号不判 FAIL）")
    bad = [k for k, v in fails.items() if v]
    print(f"[L-1] {'FAIL' if fails['L-1'] else 'PASS'} ({len(fails['L-1'])})")
    print(f"[L-2] {'FAIL' if fails['L-2'] else 'PASS'} ({len(fails['L-2'])})")
    print(f"[L-3] {'FAIL' if fails['L-3'] else 'PASS'} ({len(fails['L-3'])})")
    if not args.quiet:
        for k in ("L-1", "L-2", "L-3"):
            for it in fails[k][:8]:
                print(f"    - {k} {it}")
    print(f"FAIL 类：{bad if bad else '无'}")
    print(f"VERDICT={'FAIL' if bad else 'PASS'}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
