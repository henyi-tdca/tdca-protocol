# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
"""TDCA 每周深度核 v1（只读·零 token）

定位：日巡（_daily_patrol_v1.py）只做「账本/信箱/站点/三端」四面的轻量核对；
本脚本每周跑一次，在日巡基础上把**只在周粒度才有意义**的深项一并核掉：

  1. 日常面汇总 —— 先跑日巡，取其告警与该日报告路径（不重复输出全部内容）
  2. 件与自哈希 —— 最近 12 条记录：文件在位、sha256[:16] 与记录 self_sha256_16 相符、无 BOM／无 CRLF
  3. 治理件件名 —— 最近 12 条记录的治理件件名长度 ≤110 字符
  4. 双库件面 —— 工作区 vs 桌面归档的 NCA 件数，并列单侧件（限 12 条）
  5. 归档规模 —— 桌面归档夹文件总数，与上次周核比较给出 Δ
  6. 信箱积压 —— 各目录逐个数，并列出待办目录里的件名（限 12 条）
  7. 站点收录 —— 拉 sitemap.xml 逐路 GET，报非 200 的路
  8. 证书剩期 —— 剩余天数与预警线日期
  9. 三端头 —— 三个远端分支头（ls-remote），失败如实记，不判落后

纪律：⛔ 不写账本、⛔ 不登记 NCA、⛔ 不改被核对对象、⛔ 不对外、⛔ 不部署、⛔ 不登录账号。

产出：
  .tdca-nca/reports/patrol/WEEKLY-YYYYMMDD.txt       当周报告（覆盖写）
  .tdca-nca/reports/patrol/_PATROL-LOG.txt           追加一行 [WEEKLY] 摘要
  .tdca-nca/reports/patrol/_weekly_state.json        上次规模基线（供 Δ 比较）

用法：
  python _weekly_deep_check_v1.py             # 正常跑
  python _weekly_deep_check_v1.py --quiet     # 只落文件，不打印
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import socket
import ssl
import subprocess
import sys
import urllib.request
from datetime import datetime, timedelta, timezone

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

WS = r"C:\Users\22850\AppData\Roaming\reasonix\global-workspace"
NCA = os.path.join(WS, ".tdca-nca")
DESKTOP_ARCHIVE = r"C:\Users\22850\Desktop\TDCA归档文件夹"
DESK_NCA = os.path.join(DESKTOP_ARCHIVE, ".tdca-nca")
REPORT_DIR = os.path.join(NCA, "reports", "patrol")
SITE = "https://tdca.com.cn"
GIT = r"D:\git-mingit\portable\cmd\git.exe"
REMOTES = {
    "atomgit": "https://atomgit.com/siweihanshuzhineng/siweihanshuzhineng-TDCA.git",
    "gitee": "https://gitee.com/siweihanshuzhineng_0/tdca-protocol.git",
    "github": "https://github.com/henyi-tdca/tdca-protocol.git",
}
MAILBOX = r"C:\Users\22850\Desktop\TDCA交付取件\_MAILBOX"
MAILBOX_DIRS = ["TO-EXEC", "FROM-EXEC", "TO-WB", "FROM-WB", "DONE"]
DEEP_N = 12
MAX_ITEM_NAME = 110

# 归档镜像的已知历史缺口（归一后件名）：2026-11-02 首跑实测为历史 -D／-W 双份命名差异，
# 已由「彻底归一」消解（见 _norm_nca），本集合留作将来有真缺口时的登记位。
KNOWN_ARCHIVE_GAPS: set[str] = set()

lines: list[str] = []
alerts: list[str] = []


def add(s: str = "") -> None:
    lines.append(s)


def alert(s: str) -> None:
    alerts.append(s)
    lines.append("  ⚠️ " + s)


# ---------- 1. 日常面：先跑日巡 ----------
def run_daily() -> str | None:
    add("## 一、日常面（日巡复跑）")
    p = os.path.join(NCA, "scripts", "_daily_patrol_v1.py")
    if not os.path.exists(p):
        alert("日巡脚本缺失，本周日常面未核")
        return None
    # 已知环境现象：本机到 github:443 常被重置（多次实测），日巡会以此告警；
    # 周核里降级为「已知项」，只登记不告警，避免每周重复占版面。
    ENV_KNOWN = ("github", "Connection was reset", "Failed to connect", "头读取为空")
    try:
        r = subprocess.run([sys.executable, p, "--quiet"], capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=600)
        today = datetime.now().strftime("%Y%m%d")
        rep = os.path.join(REPORT_DIR, f"PATROL-{today}.txt")
        if os.path.exists(rep):
            txt = open(rep, encoding="utf-8").read()
            warns = [x.strip() for x in txt.splitlines() if x.strip().startswith("⚠️")]
            known = [w for w in warns if any(k in w for k in ENV_KNOWN)]
            real = [w for w in warns if w not in known]
            add(f"- 日巡报告：{os.path.relpath(rep, WS)}（真告警 {len(real)}／已知环境现象 {len(known)}）")
            for w in real[:10]:
                add("  - 真告警：" + w.replace("⚠️", "").strip())
            for w in known[:6]:
                add("  - 已知项：" + w.replace("⚠️", "").strip()[:120])
            if real:
                alert(f"日巡有 {len(real)} 条真告警（见上）")
        else:
            add(f"- 日巡执行完毕（报告未找到：{os.path.basename(rep)}）")
            if r.returncode != 0:
                alert(f"日巡返回码 {r.returncode}")
        return rep
    except Exception as e:
        alert(f"日巡执行失败：{e}")
        return None


# ---------- 2~3. 件、自哈希、件名 ----------
def _resolve(rel: str) -> str | None:
    for cand in (os.path.join(NCA, rel), os.path.join(WS, rel)):
        if os.path.exists(cand):
            return cand
    return None


def check_artifacts(records: list[dict]) -> None:
    add("")
    add(f"## 二、件与自哈希（最近 {DEEP_N} 条）")
    ok = miss = badh = badenc = 0
    for rec in records[-DEEP_N:]:
        files = rec.get("files") or []
        if not files:
            alert(f"{rec.get('gseq')} 记录无 files 字段")
            miss += 1
            continue
        p = _resolve(files[0])
        if not p:
            alert(f"{rec.get('gseq')} 件缺失：{files[0]}")
            miss += 1
            continue
        ok += 1
        raw = open(p, "rb").read()
        h = hashlib.sha256(raw).hexdigest()[:16].upper()
        if h != (rec.get("self_sha256_16") or "").upper():
            alert(f"{rec.get('gseq')} 自哈希不符：记 {rec.get('self_sha256_16')} / 算 {h}")
            badh += 1
        if raw[:3] == b"\xef\xbb\xbf" or b"\r\n" in raw:
            alert(f"{rec.get('gseq')} 编码不合规（BOM 或 CRLF）：{os.path.basename(p)}")
            badenc += 1
    add(f"- 在位 {ok}／缺失 {miss}／自哈希不符 {badh}／编码不合规 {badenc}")

    add("")
    add("## 三、治理件件名（长度上限 %d）" % MAX_ITEM_NAME)
    too_long = 0
    for rec in records[-DEEP_N:]:
        for rel in (rec.get("files") or [])[1:]:
            name = os.path.basename(rel)
            if len(name) > MAX_ITEM_NAME:
                alert(f"{rec.get('gseq')} 件名 {len(name)} 字符超限：{name[:40]}…")
                too_long += 1
    add(f"- 超限 {too_long} 件" + ("（无超限）" if too_long == 0 else ""))


# ---------- 4. 双库件面 ----------
def _norm_nca(name: str) -> str:
    """历史双份命名归一：把末尾**任意个** -D／-W 后缀全部去掉，同一号件视为一件。
    （例：xxx-D.yaml / xxx-W.yaml / xxx-D-D.yaml → xxx.yaml；既定口径，非缺陷。）"""
    return re.sub(r"(-[DW])+\.yaml$", ".yaml", name)


def check_two_libraries() -> None:
    add("")
    add("## 四、双库件面（NCA 件数·按去 -D/-W 后缀归一）")
    try:
        a_raw = [x for x in os.listdir(NCA) if x.startswith("NCA-") and x.endswith(".yaml")]
        b_raw = [x for x in os.listdir(DESK_NCA) if x.startswith("NCA-") and x.endswith(".yaml")]
        a = sorted({_norm_nca(x) for x in a_raw})
        b = sorted({_norm_nca(x) for x in b_raw})
        add(f"- 原始件数：工作区 {len(a_raw)}／桌面 {len(b_raw)}（差 {len(a_raw) - len(b_raw):+d}）"
            f"；历史 -D／-W 双份命名属既定口径，不判缺陷")
        add(f"- 归一后：工作区 {len(a)}／桌面 {len(b)}（差 {len(a) - len(b):+d}）")
        sa, sb = set(b), set(a)
        only_a = [x for x in a if x not in sa]
        only_b = [x for x in b if x not in sb]
        new_a = [x for x in only_a if x not in KNOWN_ARCHIVE_GAPS]
        known_a = [x for x in only_a if x in KNOWN_ARCHIVE_GAPS]
        if known_a:
            add(f"- 已知历史缺口 {len(known_a)} 件（登记为已知项，不告警）：" + "、".join(known_a))
        for x in new_a[:12]:
            add("  - 新增缺口（仅工作区有）：" + x)
        if only_b:
            add(f"- 归一后仅桌面有 {len(only_b)} 件（列前 12）：")
            for x in only_b[:12]:
                add("  - " + x)
        if new_a or only_b:
            alert(f"归一后双库件面出现新增差异（仅工作区 {len(new_a)}／仅桌面 {len(only_b)}）")
    except Exception as e:
        alert(f"双库件面读取失败：{e}")


# ---------- 5. 归档规模 ----------
def check_archive_scale() -> None:
    add("")
    add("## 五、归档规模（与上次周核比较）")
    try:
        total = 0
        for _root, _dirs, files in os.walk(DESKTOP_ARCHIVE):
            total += len(files)
        state_p = os.path.join(REPORT_DIR, "_weekly_state.json")
        prev = {}
        if os.path.exists(state_p):
            try:
                prev = json.load(open(state_p, encoding="utf-8"))
            except Exception:
                prev = {}
        p_total = prev.get("desktop_files")
        delta = "（首次无基线）" if p_total is None else f"（Δ {total - int(p_total):+d}）"
        add(f"- 桌面归档夹文件 {total} 件{delta}；上次基线 {p_total if p_total is not None else '-'}"
            f"／{prev.get('run_at', '-')}")
    except Exception as e:
        alert(f"归档规模统计失败：{e}")


# ---------- 6. 信箱积压 ----------
def _newest(p: str, n: int = 3) -> list[tuple[str, float]]:
    items = [x for x in os.listdir(p) if not x.startswith(".")]
    out = []
    for x in items:
        try:
            out.append((x, os.path.getmtime(os.path.join(p, x))))
        except OSError:
            pass
    out.sort(key=lambda t: t[1], reverse=True)
    return out[:n]


def _stem(name: str) -> str:
    """件名主干：去 .sha256、去扩展名、去末尾 16 位大写哈希。"""
    s = re.sub(r"\.sha256$", "", name)
    s = re.sub(r"\.[A-Za-z0-9]+$", "", s)
    return re.sub(r"-[0-9A-F]{16}$", "", s)


def check_mailbox_backlog() -> None:
    """存量规模与最近变动只作登记；「待核」判据＝回报目录里的件在 DONE 找不到对应件。
    （原件常留在 FROM-* 未移走，仅按目录件数判会天天误报，故改为对 DONE 比对主干。）"""
    add("")
    add("## 六、信箱存量与待核判定（对 DONE 比对主干）")
    try:
        done_dir = os.path.join(MAILBOX, "DONE")
        done_stems: list[str] = []
        if os.path.isdir(done_dir):
            done_stems = [_stem(x) for x in os.listdir(done_dir) if not x.startswith(".")]

        def _handled(stem: str) -> bool:
            k = stem[:40]
            return any(d.startswith(k) for d in done_stems)

        for d in MAILBOX_DIRS:
            p = os.path.join(MAILBOX, d)
            if not os.path.isdir(p):
                add(f"- {d}：目录不存在")
                continue
            items = [x for x in os.listdir(p) if not x.startswith(".")]
            latest = _newest(p, 2)
            desc = "；".join(
                f"{x[:44]}（{datetime.fromtimestamp(t).strftime('%m-%d %H:%M')}）" for x, t in latest
            ) or "-"
            add(f"- {d}：{len(items)} 件｜最近：{desc}")
            if d in ("FROM-EXEC", "FROM-WB") and items:
                pending = [x for x in items if not x.endswith(".sha256") and not _handled(_stem(x))]
                if pending:
                    for x in sorted(pending)[:8]:
                        add("  - 待核：" + x[:80])
                    alert(f"{d} 有 {len(pending)} 件回报待核（DONE 无对应件）")
                else:
                    add(f"  - 均已核（DONE 有对应件，残留 {len(items)} 件属原件留原处）")
    except Exception as e:
        alert(f"信箱读取失败：{e}")


# ---------- 7. 站点收录逐路 ----------
def _get(url: str, timeout: int = 20, retries: int = 1) -> tuple[int, int]:
    """取状态码与字节数；连接异常（-1）自动重试，避免偶发抖动写进报告。"""
    last: tuple[int, int] = (-1, 0)
    for i in range(retries + 1):
        req = urllib.request.Request(url, headers={"User-Agent": "tdca-weekly-check/1.0"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.getcode(), len(r.read())
        except urllib.error.HTTPError as e:
            return e.code, 0
        except Exception:
            last = (-1, 0)
            if i < retries:
                continue
    return last


def check_sitemap_routes() -> None:
    add("")
    add("## 七、站点收录逐路（sitemap.xml）")
    code, n = _get(f"{SITE}/sitemap.xml")
    if code != 200:
        alert(f"sitemap.xml 返回 {code}")
        return
    try:
        body = urllib.request.urlopen(
            urllib.request.Request(f"{SITE}/sitemap.xml", headers={"User-Agent": "tdca-weekly-check/1.0"}),
            timeout=20).read().decode("utf-8", "replace")
    except Exception as e:
        alert(f"sitemap 读取失败：{e}")
        return
    locs = re.findall(r"<loc>([^<]+)</loc>", body)
    add(f"- sitemap {len(locs)} 路（{n} 字节）")
    bad = []
    for u in locs:
        c, _b = _get(u)
        if c != 200:
            bad.append((u, c))
    add(f"- 逐路复检：{len(locs) - len(bad)}/{len(locs)} 为 200")
    for u, c in bad:
        alert(f"收录路非 200：{u} → {c}")


# ---------- 8. 证书剩期 ----------
def check_cert() -> None:
    add("")
    add("## 八、证书剩期")
    host = SITE.replace("https://", "").strip("/")
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((host, 443), timeout=15) as s:
            with ctx.wrap_socket(s, server_hostname=host) as ss:
                cert = ss.getpeercert()
        not_after = cert.get("notAfter", "")
        from email.utils import parsedate_to_datetime
        expiry = parsedate_to_datetime(not_after)
        if expiry.tzinfo is None:
            expiry = expiry.replace(tzinfo=timezone.utc)
        days = (expiry - datetime.now(timezone.utc)).days
        warn_line = (expiry - timedelta(days=30)).strftime("%Y-%m-%d")
        add(f"- {host} 到期 {expiry.strftime('%Y-%m-%d %H:%M')} UTC／剩 {days} 天／预警线 {warn_line}")
        if days <= 30:
            alert(f"证书剩 {days} 天，已到预警线（30 天），须安排续期")
    except Exception as e:
        alert(f"证书检查失败：{e}")


# ---------- 9. 三端头 ----------
def check_remotes() -> None:
    add("")
    add("## 九、三端分支头（不判落后，只记实况）")
    if not os.path.exists(GIT):
        alert("便携 git 不在位，三端头未核")
        return
    for name, url in REMOTES.items():
        try:
            r = subprocess.run([GIT, "ls-remote", "--heads", url],
                               capture_output=True, text=True, encoding="utf-8",
                               errors="replace", timeout=45)
            out = r.stdout or ""
            head = "-"
            for ln in out.splitlines():
                if re.search(r"refs/heads/(main|master)$", ln):
                    head = ln.split()[0][:10]
                    break
            if r.returncode != 0 or head == "-":
                err = (r.stderr or "").strip()[:120]
                if name == "github" and any(k in err for k in ("Connection was reset", "Failed to connect", "timed out", "Timeout")):
                    add(f"- {name}：本机网络到 443 不通（已知环境现象，不告警）——{err[:80]}")
                else:
                    alert(f"{name} 取头失败（返回码 {r.returncode}）：{err}")
            else:
                add(f"- {name}：{head}")
        except subprocess.TimeoutExpired:
            alert(f"{name} 取头超时（45s）")
        except Exception as e:
            alert(f"{name} 取头异常：{e}")


# ---------- 主流程 ----------
def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    os.makedirs(REPORT_DIR, exist_ok=True)
    now = datetime.now()
    add(f"# TDCA 每周深度核 · {now.strftime('%Y-%m-%d %H:%M')}")
    add("")

    records: list[dict] = []
    try:
        import yaml
        reg = yaml.safe_load(open(os.path.join(NCA, "NCA-REGISTRY.yaml"), encoding="utf-8"))
        records = reg.get("records") or []
    except Exception as e:
        alert(f"账本读取失败，件面深度核跳过：{e}")

    run_daily()
    if records:
        check_artifacts(records)
    check_two_libraries()
    check_archive_scale()
    check_mailbox_backlog()
    check_sitemap_routes()
    check_cert()
    check_remotes()

    # 收尾
    add("")
    add("## 汇总结论")
    if alerts:
        add(f"- 告警 {len(alerts)} 条（见各节 ⚠️）")
    else:
        add("- 告警 0 条：各项均在口径内")

    out = os.path.join(REPORT_DIR, f"WEEKLY-{now.strftime('%Y%m%d')}.txt")
    with open(out, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lines) + "\n")

    # 规模基线
    try:
        total = 0
        for _root, _dirs, files in os.walk(DESKTOP_ARCHIVE):
            total += len(files)
        json.dump({"run_at": now.strftime("%Y-%m-%d %H:%M"), "desktop_files": total},
                  open(os.path.join(REPORT_DIR, "_weekly_state.json"), "w", encoding="utf-8"),
                  ensure_ascii=False, indent=1)
    except Exception:
        pass

    # 累计日志
    log = os.path.join(REPORT_DIR, "_PATROL-LOG.txt")
    with open(log, "a", encoding="utf-8", newline="\n") as f:
        f.write(f"[WEEKLY] {now.strftime('%Y-%m-%d %H:%M')} 告警 {len(alerts)}"
                f"｜{os.path.basename(out)}\n")

    if not args.quiet:
        print("\n".join(lines))
        print(f"\n报告：{out}")
    return 1 if alerts else 0


if __name__ == "__main__":
    sys.exit(main())
