# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
"""TDCA 零成本常驻巡检 v1（只读）

用途：Windows 计划任务每日跑一次，**不调用任何模型、不消耗 token**，只在本地做只读核对，
       把结果落到 .tdca-nca/reports/patrol/ 下，创始人开机即可一眼看到"账本/信箱/站点"三面实况。

纪律：
  ⛔ 不写账本、⛔ 不登记 NCA、⛔ 不改任何被核对对象；只读文件与只在报告目录内落盘。
  ⛔ 不对外、⛔ 不部署、⛔ 不登录任何账号（只做匿名 HTTPS 取头与端口连通性）。

产出：
  .tdca-nca/reports/patrol/PATROL-YYYYMMDD.txt   当日报告（覆盖写）
  .tdca-nca/reports/patrol/_PATROL-LOG.txt       累计一行摘要（追加，最新在末）

用法：
  python _daily_patrol_v1.py            # 正常跑
  python _daily_patrol_v1.py --quiet    # 只落文件，不打印
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import socket
import ssl
import subprocess
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone

import yaml

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

WS = r"C:\Users\22850\AppData\Roaming\reasonix\global-workspace"
NCA = os.path.join(WS, ".tdca-nca")
DESK_NCA = r"C:\Users\22850\Desktop\TDCA归档文件夹\.tdca-nca"
REPORT_DIR = os.path.join(NCA, "reports", "patrol")
SITE = "https://tdca.com.cn"
GIT = r"D:\git-mingit\portable\cmd\git.exe"
REMOTES = {
    "atomgit": "https://atomgit.com/siweihanshuzhineng/siweihanshuzhineng-TDCA.git",
    "gitee": "https://gitee.com/siweihanshuzhineng_0/tdca-protocol.git",
    "github": "https://github.com/henyi-tdca/tdca-protocol.git",
}

lines: list[str] = []
alerts: list[str] = []


def add(s: str = "") -> None:
    lines.append(s)


def alert(s: str) -> None:
    alerts.append(s)
    lines.append("  ⚠️ " + s)


# ---------- 1. 账本 ----------
def check_ledger() -> tuple[int, int]:
    reg = os.path.join(NCA, "NCA-REGISTRY.yaml")
    dreg = os.path.join(DESK_NCA, "NCA-REGISTRY.yaml")
    add("## 一、账本")
    n = mx = 0
    try:
        m1 = hashlib.md5(open(reg, "rb").read()).hexdigest().upper()
        m2 = hashlib.md5(open(dreg, "rb").read()).hexdigest().upper()
        add(f"- 双库 MD5：{'一致' if m1 == m2 else '⚠️ 不一致'}")
        if m1 != m2:
            alert("双库 MD5 不一致（工作区 vs 桌面归档）")
    except Exception as e:
        alert(f"双库读取失败：{e}")
    try:
        import yaml
        r = yaml.safe_load(open(reg, encoding="utf-8"))
        nums = [int(x["gseq"][5:]) for x in r["records"]]
        n, mx = len(nums), max(nums)
        gap = mx - n
        add(f"- records {n}／max {mx}／空号 {gap}（历史既定 GSEQ-<n> 属正常）")
        if gap > 1:
            alert(f"空号 {gap} 条，超出历史既定 1 条，请查")
    except Exception as e:
        alert(f"账本解析失败：{e}")
    return n, mx


def check_chain() -> None:
    p = os.path.join(NCA, "scripts", "_nca_chain_verify_v1.py")
    if not os.path.exists(p):
        alert("链验脚本缺失")
        return
    try:
        r = subprocess.run([sys.executable, p, "--quiet"], capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=300)
        tail = [x for x in (r.stdout or "").strip().splitlines() if x.strip()]
        verdict = tail[-1] if tail else "(无输出)"
        add(f"- 链验：{verdict}")
        if "VERDICT=PASS" not in (r.stdout or ""):
            alert("链验非 PASS")
    except Exception as e:
        alert(f"链验执行失败：{e}")


# ---------- 2. 信箱 ----------
def check_mailbox() -> None:
    add("")
    add("## 二、信箱")
    p = os.path.join(NCA, "scripts", "_mailbox_ledger_v1.py")
    if not os.path.exists(p):
        alert("信箱台账脚本缺失")
        return
    try:
        r = subprocess.run([sys.executable, p, "--check"], capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=300)
        out = r.stdout or ""
        for ln in out.splitlines():
            s = ln.strip()
            if s.startswith("扫描件数") or s.startswith("状态分布") or "盘上有台账无" in s or "待处理" in s:
                add("- " + s)
        if "盘上有台账无 0" in out and "待处理（NEW/PENDING）0" not in out:
            alert("信箱有收件待处理，请核")
        if "盘上有台账无 0" not in out:
            alert("信箱台账对账非四零")
    except Exception as e:
        alert(f"信箱台账执行失败：{e}")


# ---------- 3. 站点公开面 ----------
def _head(url: str, timeout: int = 20) -> tuple[int, int]:
    req = urllib.request.Request(url, method="GET", headers={"User-Agent": "TDCA-Patrol/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, len(r.read())


def _cert_days(host: str) -> tuple[str, int]:
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    with socket.create_connection((host, 443), timeout=15) as s:
        with ctx.wrap_socket(s, server_hostname=host) as ss:
            der = ss.getpeercert(binary_form=True)
    pem = ssl.DER_cert_to_PEM_cert(der)
    tmp = os.path.join(REPORT_DIR, "_cert.pem")
    with open(tmp, "w", encoding="ascii") as f:
        f.write(pem)
    try:
        info = ssl._ssl._test_decode_cert(tmp)  # CPython 内部解析器，仅读本地临时 PEM
    finally:
        try:
            os.remove(tmp)
        except Exception:
            pass
    notafter = info.get("notAfter", "")
    if not notafter:
        return "", -1
    dt = datetime.strptime(notafter, "%b %d %H:%M:%S %Y GMT").replace(tzinfo=timezone.utc)
    return dt.astimezone().strftime("%Y-%m-%d %H:%M"), (dt - datetime.now(timezone.utc)).days


def check_site() -> None:
    add("")
    add("## 三、站点公开面（匿名只读）")
    try:
        st, sz = _head(SITE + "/")
        add(f"- 入口：{st}（{sz}B）")
        if st != 200:
            alert(f"站点入口非 200：{st}")
    except Exception as e:
        alert(f"站点入口不可达：{e}")
        return
    try:
        na, days = _cert_days("tdca.com.cn")
        if days < 0:
            add("- 证书：解析失败（未判）")
        else:
            add(f"- 证书到期：{na}（剩约 {days} 天；预警线 30 天）")
            if days <= 30:
                alert(f"证书剩 {days} 天，已进预警线，请续期")
            elif days <= 45:
                add(f"  ℹ️ 距预警线约 {days - 30} 天")
    except Exception as e:
        add(f"- 证书：读取失败（{e}）")
    for p in ("/robots.txt", "/sitemap.xml"):
        try:
            st, sz = _head(SITE + p)
            add(f"- {p}：{st}（{sz}B）")
            if st != 200:
                alert(f"{p} 非 200")
        except Exception as e:
            alert(f"{p} 读取失败：{e}")
    for port in (22, 80, 443):
        if _tcp("tdca.com.cn", port, retries=3):
            add(f"- 端口 {port}：开")
        elif port == 22:
            # SSH 常被运营商/对端限流，探测抖动大；在册要求通，但不以单次探测报假警
            add("- 端口 22：本次探测不通（SSH 易受限流；非对外服务面，仅记提示）")
        else:
            alert(f"对外端口 {port} 不通")
    for port in (8080, 3389):
        if _tcp("tdca.com.cn", port):
            alert(f"应关端口 {port} 竟然可达，请查")
        else:
            add(f"- 应关端口 {port}：关（符合）")


def _tcp(host: str, port: int, ms: int = 3000, retries: int = 1) -> bool:
    for i in range(retries):
        try:
            with socket.create_connection((host, port), timeout=ms / 1000):
                return True
        except Exception:
            if i + 1 < retries:
                import time
                time.sleep(1.0)
    return False


# ---------- 4. 三端 ----------
def check_remotes() -> None:
    add("")
    add("## 四、三端头（只取引用，不取内容）")
    if not os.path.exists(GIT):
        add("- 便携 git 不在位，跳过")
        return
    heads = {}
    for name, url in REMOTES.items():
        try:
            r = subprocess.run([GIT, "ls-remote", url, "HEAD"], capture_output=True, text=True,
                               encoding="utf-8", errors="replace", timeout=120)
            h = (r.stdout or "").strip().split("\t")[0][:10]
            heads[name] = h or "(空)"
            add(f"- {name}：{h or '(空)'}")
            if not h:
                err = ((r.stderr or "").strip().splitlines() or ["(无 stderr)"])[-1][:120]
                alert(f"{name} 头读取为空（{err}）——网络或限流，非仓库缺陷")
        except Exception as e:
            heads[name] = "(空)"
            add(f"- {name}：读取失败（{e}）")
            alert(f"{name} 头读取异常：{e}")
    uniq = {v for v in heads.values() if v and v != "(空)"}
    if len(uniq) > 1:
        add(f"  ℹ️ 可读端头不一致（{len(uniq)} 个不同）——按在册口径『镜像判同树、不以头判落后』，头不同属正常；如需判同树请另跑核对")


# ---------- 到期提醒（只读消费 _DUE-REMINDERS.yaml）----------
def check_due() -> None:
    add("")
    add("## 五、到期提醒")
    path = os.path.join(NCA, "_DUE-REMINDERS.yaml")
    if not os.path.exists(path):
        add("- 清单不存在，跳过（不影响本巡其它项）")
        return
    try:
        with open(path, encoding="utf-8") as f:
            doc = yaml.safe_load(f) or {}
    except Exception as e:
        add(f"- 清单读取失败：{e}")
        alert("到期提醒清单读取失败")
        return
    today = datetime.now().astimezone().date()
    due_hit, pending, closed = [], 0, 0
    for it in doc.get("items") or []:
        if it.get("status") == "closed":
            closed += 1
            continue
        d = str(it.get("due") or "").strip()
        if not d:
            continue
        try:
            dd = datetime.strptime(d, "%Y-%m-%d").date()
        except ValueError:
            add(f"- 日期写法无法解析：{it.get('id')} → {d!r}（⛔ 通配）")
            continue
        left = (dd - today).days
        if left <= 0:
            due_hit.append((it.get("id"), d, left, it.get("what")))
        else:
            pending += 1
    for _id, d, left, what in due_hit:
        add(f"- 🔔 **{_id}** 到期（`{d}`，{'已逾期 %d 天' % -left if left < 0 else '今日到期'}）：{what}")
        alert(f"到期提醒 {_id}（{d}）")
    add(f"- 计数：到期 {len(due_hit)} 项｜未到期 {pending} 项｜已销 {closed} 项")


# ---------- 主流程 ----------
def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()

    os.makedirs(REPORT_DIR, exist_ok=True)
    now = datetime.now().astimezone()
    add(f"# TDCA 常驻巡检报告 · {now.strftime('%Y-%m-%d %H:%M')}（+08）")
    add("> 零 token 只读巡检：不调模型、不写账本、不登录账号、不对外。")
    add("")

    n, mx = check_ledger()
    check_chain()
    check_mailbox()
    check_site()
    check_remotes()
    check_due()

    add("")
    add("## 六、结论")
    if alerts:
        add(f"- ⚠️ 需关注 {len(alerts)} 项：")
        for s in alerts:
            add(f"  - {s}")
    else:
        add("- ✅ 全项正常，无需处理。")

    text = "\n".join(lines) + "\n"
    day = now.strftime("%Y%m%d")
    out = os.path.join(REPORT_DIR, f"PATROL-{day}.txt")
    with open(out, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    summary = f"{now.strftime('%Y-%m-%d %H:%M')} | records {n} max {mx} | 告警 {len(alerts)} | {('; '.join(alerts)[:180] if alerts else '全正常')}"
    with open(os.path.join(REPORT_DIR, "_PATROL-LOG.txt"), "a", encoding="utf-8", newline="\n") as f:
        f.write(summary + "\n")

    if not a.quiet:
        print(text)
        print("报告已落：", out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
