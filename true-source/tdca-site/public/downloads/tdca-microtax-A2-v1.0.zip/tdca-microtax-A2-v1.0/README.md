# TDCA 微交付税收模块（tdca-microtax，A-2 货架包）

## 这是什么

智能体微交付（micro-delivery）的**实时税收计算 + 智能合约税收预缴**组件：
交付计量 → T(y_t) 分项税额（调度税 / 版税 / 交易费）→ 税款预缴托管 → 税后净额进入正和分配。
本包为 A-2「微交付税收」货架发行包，仅含运行必需面（白名单制出包）。

## 依赖

- 运行：Python ≥ 3.10，**仅标准库**；另需**同货架 `tdca-nsfl-compiler`（A-3）包同环境可用**
  （`microtax.tax_officer` 按 TAXLAW-001 fail-closed 设计硬依赖其法规基座，
  缺失时 `import microtax` 将按设计拒绝加载）。
- 测试：`pytest >= 7.0`（可选，仅 `tests/` 需要）。
- 说明：`tax_calculator` / `event_tax_calculator` 对 `call_rules_engine.TaxRates`
  与 `positive_sum_integration` 对 `translator_market.mou_split` 均为
  try/except 软导入，缺失时自动使用包内 dataclass / `_fallback_split` 兜底。

## 怎么跑

一行最小示例（1000 元日抛交付 → 税 27.50，税后净额 972.50）：

```bash
python -c "from microtax.models import MicroDelivery; from microtax.tax_calculator import MicroTaxCalculator; d = MicroDelivery(delivery_id='demo-1', scene='demo', value=1000.0); print(MicroTaxCalculator().compute_taxes(d))"
```

运行测试（可选）：

```bash
python -m pytest tests -q
```

## 本包排除清单（具名）

| 排除件 | 判据 |
|--------|------|
| `microtax/economic_cognition.py` | 硬依赖包外基座（tdca-toolchain 认知距离 + tdca-utility-genie 求解器），超出"仅标准库"依赖信封 |
| `microtax/configurator.py` | 唯一依赖上述被排除模块，连带排除 |
| `tests/test_cognition.py` / `tests/test_taxlaw.py` / `tests/test_bias.py` / `tests/test_ecoweight.py` / `tests/test_configurator.py` | 测例目标为被排除模块或缺失基座，保留则测试无法通过 |

排除后 `microtax/__init__.py` 的对应导出已随之移除（仅暂存副本改动，不动源仓）。

## 许可

Apache License 2.0（见随包 `LICENSE` 全文）。本包以货架形态对外提供，
不代表对许可范围外任何权利的声称。
