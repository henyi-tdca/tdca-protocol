# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
"""一键起盘：建五夹 ＋ 写样例 ＋ 跑自测 ＋ 打印首份台账（零依赖 · 仅标准库）。

用法：
  python _mailbox_init_v1.py                 # 在脚本同级 mailbox/ 起盘
  python _mailbox_init_v1.py --mailbox-root <路径>
自测项：五夹齐／样例旁注 17 B 合规／样例台账可解析／状态分布可打印。
⛔ 不覆盖既有同名件（同名同内容跳过，同名异内容报 DIFF 拒改）。
"""
import argparse
import hashlib
import json
import os
import shutil
import sys

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
FOLDERS = ["TO-EXEC", "FROM-EXEC", "TO-WB", "FROM-WB", "DONE"]
SAMPLE_LETTER = """MAIL id=SAMPLE-001 sha256_16=PENDING0000000 口径=示例 from=示例方 to=TO-EXEC 性质=样例·虚构 事由=一键起盘样例信（⛔ 真实件，仅演示首行七段与旁注形态）

# 样例信（虚构）

这是起盘脚本写入的演示件：真实使用时以正式回报件替换。件名明标虚构，哈希不具效力。
"""

SAMPLE_LEDGER = {
    "generated_at": "2026-11-05T00:00:00+08:00",
    "version": "V1.1",
    "rule": "每件必有一条台账行；无台账行不得开工核；台账状态须与磁盘位置一致（本脚本对账）",
    "counts": {"NEW": 1, "SENT": 1},
    "items": [
        {"file": "SAMPLE-虚构件-收件一.md", "box": "FROM-EXEC", "size": 0, "sha256_16": "0000000000000000",
         "received_at": "2026-11-05 00:00", "state": "NEW", "basis": "", "note": "虚构样例",
         "closed_at": "", "ack_at": "", "ack_by": "", "ack_evidence": "", "ack_sha16": ""},
        {"file": "SAMPLE-虚构件-发件一.md", "box": "TO-EXEC", "size": 0, "sha256_16": "1111111111111111",
         "received_at": "2026-11-05 00:00", "state": "SENT", "basis": "", "note": "虚构样例",
         "closed_at": "", "ack_at": "", "ack_by": "", "ack_evidence": "", "ack_sha16": ""},
    ],
}


def sha16_bytes(b):
    return hashlib.sha256(b).hexdigest().upper()[:16]


def write_once(path, data, binary=False):
    if os.path.exists(path):
        old = open(path, "rb").read()
        new = data if binary else data.encode("utf-8")
        if sha16_bytes(old) != sha16_bytes(new):
            print("DIFF 同名异内容，拒改：", path)
            return False
        print("SKIP 同名同内容已在位：", os.path.basename(path))
        return True
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if binary:
        with open(path, "wb") as f:
            f.write(data)
    else:
        with open(path, "w", encoding="utf-8", newline="\n") as f:
            f.write(data)
    print("OK 写：", path)
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mailbox-root", default=os.path.join(SCRIPT_DIR, "mailbox"),
                    help="信箱根（默认脚本同级 mailbox/）")
    a = ap.parse_args()
    MB = os.path.abspath(a.mailbox_root)

    ok = True
    print("== 1. 建五夹 ==")
    for d in FOLDERS:
        p = os.path.join(MB, d)
        os.makedirs(p, exist_ok=True)
        print("  ", d)

    print("== 2. 写样例 ==")
    h = sha16_bytes(SAMPLE_LETTER.encode("utf-8"))
    letter = SAMPLE_LETTER.replace("sha256_16=PENDING0000000", "sha256_16=" + h)
    ok &= write_once(os.path.join(MB, "TO-EXEC", "SAMPLE-虚构件-001.md"), letter)
    ok &= write_once(os.path.join(MB, "TO-EXEC", "SAMPLE-虚构件-001.md.sha256"), h + "\n")
    ok &= write_once(os.path.join(MB, "ledger.sample.json"),
                     json.dumps(SAMPLE_LEDGER, ensure_ascii=False, indent=1))

    print("== 3. 自测 ==")
    side = open(os.path.join(MB, "TO-EXEC", "SAMPLE-虚构件-001.md.sha256"), "rb").read()
    t1 = len(side) == 17 and side.endswith(b"\n") and side[:16].decode().isupper()
    print("  旁注 17B/末0A/大写16位 合规 =", t1)
    doc = json.load(open(os.path.join(MB, "ledger.sample.json"), encoding="utf-8"))
    t2 = isinstance(doc.get("items"), list) and len(doc["items"]) >= 1
    print("  样例台账可解析，条目 =", len(doc.get("items") or []))
    missing = [d for d in FOLDERS if not os.path.isdir(os.path.join(MB, d))]
    t3 = not missing
    print("  五夹齐 =", t3, ("缺：" + str(missing)) if missing else "")
    ok = ok and t1 and t2 and t3

    print("== 4. 首份台账（样例态分布） ==")
    counts = doc.get("counts") or {}
    for k in ("NEW", "PENDING", "VERIFIED", "ACKED", "CLOSED", "SENT"):
        if k in counts:
            print(f"   {k} {counts[k]}")
    print("== 起盘", "OK ==" if ok else "FAIL（见上）==")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
