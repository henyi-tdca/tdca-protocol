# TDCA 信箱协议 bundle 包（tdca-mailbox-bundle-v1.0）

## 是什么

一键起盘包：建五夹（TO-EXEC／FROM-EXEC／TO-WB／FROM-WB／DONE）＋ 写样例信与样例台账 ＋ 自测 ＋ 打印首份台账。附脱敏样例账本 `ledger.sample.json`（虚构件名明标「虚构」，哈希全 0／全 1，⛔ 真实件名零命中）。

## 依赖

**零依赖**：Python ≥ 3.10 纯标准库。

## 怎么跑（一行命令）

```bash
python _mailbox_init_v1.py                  # 在脚本同级 mailbox/ 起盘
python _mailbox_init_v1.py --mailbox-root <路径>
```

⛔ 不覆盖既有同名异内容件（报 DIFF 拒改）；同名同内容跳过。

## 许可

Apache-2.0（见 `LICENSE`）。
