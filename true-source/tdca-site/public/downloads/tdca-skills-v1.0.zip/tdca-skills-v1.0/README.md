# TDCA 技能包 v1.0 出包（tdca-skills-v1.0.zip）

> 版本：v1.0 ｜ 来源：TDCA 协议仓 `skills/reasonix/skills/`（main 提交 `8e15301`）在册对外 5 件（参数化改造版，非绑本机路径版）
> 许可：随仓公开区（各 SKILL.md 头部标注为准）｜ 本包为 TDCA 自研件，许可由 TDCA 自选
> 性质：对外技能包（公开货架件）；⛔ 仅含在册 5 件，未扩为 31 件，无绑本机路径版本

## 一、这是什么

五件 TDCA 技能（Skill）的 SKILL.md 文本，每件描述一类智能体可执行的工作流与其调用的仓内公开工具：

| 技能件 | 调用什么（仓内公开路径） | 一句话用途 |
|---|---|---|
| `tdca-cypress-pool` | `tools/cypress_pool/meter.py`／`cli.py` | Cypress 计量池：配置池形态①的计量与观测 |
| `tdca-maka-nca` | `tools/maka_nca/converter.py`／`validator.py`／`cli.py` | Maka 运行时事件 → 存证标准化＋正和验证 |
| `tdca-paperclip-orch` | `tools/paperclip_nca/adapter.py`／`cli.py` | Paperclip 编排协议 → 协作语义编译 |
| `tdca-pi-compiler` | `tools/pi_nca/compiler.py`／`cli.py` | 构建动作 → 制度语义编译 |
| `tdca-thingsboard-pool` | `tools/thingsboard_pool/gateway.py`／`cli.py` | ThingsBoard 设备池接入与合成数据标注 |

上表 11 条工具路径已逐条直核在仓（11/11 存在，公开 `tools/` 区内）。

## 二、包结构与用法

```
tdca-skills-v1.0/
├── README.md（本件）
├── selftest.py（随包自测）
├── file-manifest.json（5 件 sha256 清单）
└── skills/<技能名>/SKILL.md × 5
```

用法：将 `skills/<技能名>/` 目录整体复制到支持 SKILL.md 规范的宿主技能目录（如 `skills/` 下），由宿主按 SKILL.md 描述调度；被调工具脚本须取自 TDCA 协议仓公开区 `tools/`（本包不含工具本体，⛔ 不替代仓库克隆）。

## 三、依赖声明（如实）

**零第三方依赖**：5 件 SKILL.md 为 Markdown 文本；随包自测 `selftest.py` 仅用 Python 标准库。技能运行时被调工具脚本的解释器需求以各工具件自身声明为准。

## 四、自测

```bash
python selftest.py
```

检查：5 件在包且非空 → 哈希与清单逐位一致 → 每件均引用 `tools/` 公开路径 → 无本机绝对路径样式。退出码：`0` 全过；`1` 有失败项；`2` 用法错误（须在包根运行）。

## 五、边界与不该用（⛔）

- ⛔ 本包只含在册 5 件；其余 26 件按在册裁定不入仓对外（因由见智库范围裁定件），本包**不**收录。
- ⛔ 5 件为参数化改造版：所引工具路径前缀已对齐仓内公开区 `tools/`，⛔ 无绑本机绝对路径版本。
- 技能描述中的合成／演示数据要求（SIMULATED 标注）为硬约束，宿主环境照此执行，⛔ 不冒充真实运行数据。
- 本包为技能定义文本，不含可执行工具本体；单独下载本包无法运行工具，须配合 TDCA 协议仓公开区。

## 六、六模式复扫读数（照实）

出包后六模式复扫：其余五模式 0 命中；「大写字母 I 开头接数字」样式命中 19 处，**全部为制度条目引用**（协作／停机／自反化合／合成标注等条目号），非内部件流水编号。此 19 处为在册 5 件既有内容（冻结语义，出包未改一字），未做剥离。编号说明详见下节（承核证单裁定）。

## 七、编号说明（承核证单裁定）

本包 19 处命中（「大写字母 I 开头接数字」样式）属**制度条目引用**：五件 SKILL.md 为在册对外技能件，文内引用协作／停机／自反化合／合成标注等制度条目号以锚定行为约束，系技能语义的一部分，非内部件流水编号，亦非凭据／本机路径。源件为仓内公开区件，出包逐字原样。

## 八、速查

| 要做什么 | 去哪 |
|---|---|
| 计量池接入 | `skills/tdca-cypress-pool/`（形态①配置池） |
| 事件存证标准化 | `skills/tdca-maka-nca/` |
| 编排协作编译 | `skills/tdca-paperclip-orch/` |
| 构建制度语义 | `skills/tdca-pi-compiler/` |
| 设备池接入 | `skills/tdca-thingsboard-pool/` |
| 核对包完整性 | `python selftest.py` |

*出包：TDCA 执行侧 · v1.0 · 构建自 main `8e15301`；在册 5 件口径，⛔ 不扩 31 件。*
