# -*- coding: utf-8 -*-
"""tdca-inverse-solver-v1.0 随包自测（纯标准库；退出码约定见下）

退出码：
  0 = 全部自检通过
  1 = 有自检项失败（输出 [FAIL] 明细）
  2 = 用法／环境错误（本包零第三方依赖，正常环境不应触发）

用法：
  python selftest.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from solvers.inverse_function_solver import (  # noqa: E402
    ConfigSpace, InverseFunctionSolver, InverseSolution,
)

FAILS = []


def check(name, fn):
    try:
        fn()
        print(f"[PASS] {name}")
    except Exception as e:  # noqa: BLE001 - 自测需全捕
        FAILS.append(f"{name}: {e!r}")
        print(f"[FAIL] {name}: {e!r}")


def t_feasible():
    s = InverseFunctionSolver(samples=2000, random_seed=42)
    sol = s.solve(target_utility=5.0, utility_function=lambda c: c['x'],
                  config_space=ConfigSpace(bounds={'x': (0.0, 10.0)}, hard_constraints=['x <= 10']),
                  tolerance=0.1)
    assert sol.feasibility == 'feasible'
    assert sol.predicted_utility >= 4.5
    assert 'x' in sol.config_vector


def t_infeasible_nsfl():
    s = InverseFunctionSolver(samples=2000, random_seed=42)
    sol = s.solve(target_utility=999.0, utility_function=lambda c: c['x'],
                  config_space=ConfigSpace(bounds={'x': (0.0, 1.0)}, hard_constraints=['x <= 1']),
                  tolerance=0.01)
    assert sol.feasibility == 'infeasible'
    assert sol.config_vector == {}
    assert any('NSFL-TRIGGER' in str(t) for t in sol.nca_trace)


def t_validate_catches_bad():
    s = InverseFunctionSolver(samples=10, random_seed=1)
    bad = InverseSolution(config_vector={'x': 1.0}, predicted_utility=0.0,
                          confidence_interval=(0, 0), feasibility='infeasible',
                          cost=0.0, nca_trace=[{'status': 'OK'}])
    try:
        s.validate(bad)
    except ValueError as e:
        assert '[NSFL-TRIGGER]' in str(e)
    else:
        raise AssertionError('validate 未拦截缺熔断记录的不可行解')


def t_cost_min():
    s = InverseFunctionSolver(samples=2000, random_seed=42)
    sol = s.solve(target_utility=5.0, utility_function=lambda c: c['x'],
                  config_space=ConfigSpace(bounds={'x': (0.0, 10.0)}),
                  cost_function=lambda c: c['x'], tolerance=0.1)
    assert sol.config_vector['x'] <= 5.5  # 成本最小优先


check('可行反函数解', t_feasible)
check('无可行解 → 熔断', t_infeasible_nsfl)
check('validate 拦截缺熔断记录的不可行解', t_validate_catches_bad)
check('多解成本最小选择', t_cost_min)

print('-' * 60)
if FAILS:
    print(f'[FAIL] {len(FAILS)} 项未过')
    sys.exit(1)
print('[OK] 全部 4 项自检通过')
sys.exit(0)
