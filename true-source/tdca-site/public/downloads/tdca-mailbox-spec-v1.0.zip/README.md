# TDCA 信箱协议 spec 包（tdca-mailbox-spec-v1.0）

## 是什么

`MAILBOX-COLLAB` 产品线的协议规范包：`TDCA-SPEC-MAILBOX-001 V1.0-FROZEN` 双版本（人读版＋机读版）＋ 附件A（V0.11 全部条款，与正文同等效力）＋ 目录约定件（五夹目录／回报首行七段／状态机图）。

| 件 | 内容 |
|---|---|
| `TDCA-SPEC-MAILBOX-001-V1.0-FROZEN-…人读版….md` | 条例正文（附条件生效：灰度补录条件见第二章） |
| `TDCA-SPEC-MAILBOX-001-V1.0.yaml` | 条例机读版（含附件A指针与判据/断言/负空间） |
| `TDCA-SPEC-MAILBOX-001-V0.11-…人读版….md` | 附件A 人读版（全部条款） |
| `TDCA-SPEC-MAILBOX-001-V0.11.yaml` | 附件A 机读版 |
| `mailbox-conventions.md` | 五夹目录约定＋回报首行七段＋状态机图（引在册原文，出处逐条标注） |

⚠️ 条例为**附条件生效**：`2026-11-20` 前须补录灰度门回报与失效模式三查，失败自动撤销退回草案（见正文第二章）。

## 依赖

无（纯文档）。

## 怎么跑

无需运行：供人读与机验器引用。机验断言实现见 refimpl 包 `_mbx_assert_v011.py`。

## 许可

Apache-2.0（见 `LICENSE`）。条例原文为其在册形态，编号体系属协议本体，未作清编号处理。
