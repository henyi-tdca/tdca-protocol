# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
"""
LegalAgentInterface（T-LEGAL-002 输出对齐）
制度锚定: TDCA-TASK-LEGAL-001-002 §四（接口冻结条件: T-LEGAL-002 验收通过 + D-2 W2 输出就绪）
版本: V0.1 | 状态: 开发中
SPDX-License-Identifier: Apache-2.0
NSFL-Declaration:
  - generate_legal_nca 必须生成标准 NCA（法律依据/冲突类型/严重度/建议处置/审计轨迹）
  - validate 输入来自 D-2 并集引擎 NegativeSpaceUnion
"""

import hashlib
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from legal_agent.conflict_engine import LegalConflictEngine, PrelabelResult
from legal_agent.kg_legal import KGLegal
from legal_agent.nsfl_filter import NSFLFilter


@dataclass
class ValidationResult:
    """并集引擎输出法律有效性校验结果"""

    valid: bool
    legal_conflicts: List[dict] = field(default_factory=list)
    illegal_paths: List[str] = field(default_factory=list)   # 非法替代路径
    premium_ok: bool = True
    reasons: List[str] = field(default_factory=list)
    nca_ref: Optional[str] = None


@dataclass
class LegalNCA:
    """法学家判断 → 标准 NCA（T-LEGAL-001/002 §三 generate_legal_nca）"""

    nca_id: str
    case_ref: str
    legal_basis: List[str]       # 法律依据（法条引用）
    conflict_type: str
    severity: str
    recommended_action: str      # 建议处置
    confidence: float
    audit_trail: dict            # 审计轨迹（通道/规则/耗时）
    timestamp: int
    human_escalated: bool


class LegalAgentInterface:
    """TDCA-AGENT-LEGAL-001 对外接口（prelabel / validate / generate_legal_nca）"""

    def __init__(self, kg: Optional[KGLegal] = None, engine: Optional[LegalConflictEngine] = None):
        self.kg = kg or KGLegal()
        self.engine = engine or LegalConflictEngine(self.kg)
        self.filter = NSFLFilter()

    # ------------------------------------------------------------------
    # prelabel（对齐接口契约: >0.95 直标 / 0.70-0.95 建议标注待确认 / <0.70 边界案例上报）
    # ------------------------------------------------------------------
    def prelabel(self, scene_a: dict, scene_b: dict) -> PrelabelResult:
        # NSFL 预检: 涉政/涉隐私 → 强制 ESCALATE + 拒绝自动标注
        precheck = self.filter.filter_scene_pair(scene_a, scene_b)
        if precheck["blocked"]:
            return PrelabelResult(
                scene_a=scene_a["scene_id"],
                scene_b=scene_b["scene_id"],
                confidence=0.0,
                tier="ESCALATE",
                conflict=None,
                reasoning="NSFL 预检阻断: " + "; ".join(precheck["reasons"]),
                channels={"nsfl_filter": precheck},
            )
        result = self.engine.prelabel(scene_a, scene_b)
        # NSFL 过滤理由并入审计
        result.channels["nsfl_filter"] = precheck
        return result

    # ------------------------------------------------------------------
    # validate（D-2 并集引擎输出法律有效性校验）
    # ------------------------------------------------------------------
    def validate(self, union_result: dict) -> ValidationResult:
        """校验 NegativeSpaceUnion: 冲突合法性 / 替代路径合法性 / risk_premium 合理性"""
        reasons = []
        illegal_paths = []

        conflict_set = union_result.get("conflict_set") or []
        alt_paths = union_result.get("recommended_alt_path") or []
        risk_premium = union_result.get("risk_premium", 0.0)

        legal_conflicts = []
        for c in conflict_set:
            # LEGAL 型冲突恒 HIGH + 无 alt_path（ID<n>）
            if c.get("fuse_type") == "LEGAL" or c.get("severity") == "HIGH":
                legal_conflicts.append(c)
                if c.get("alt_path") is not None or (alt_paths and c.get("severity") == "HIGH"):
                    illegal_paths.append(f"{c.get('ns_type')}: LEGAL/HIGH 冲突不得配替代路径")

        # 熔断语义: LEGAL 冲突存在 → 引擎输出应为 TRIGGERED + risk_premium=1.0
        if legal_conflicts:
            if risk_premium < 1.0:
                reasons.append(f"LEGAL 冲突存在但 risk_premium={risk_premium} < 1.0（熔断语义要求恒 1.0）")
            if union_result.get("status") not in ("TRIGGERED", "REJECTED"):
                reasons.append(f"LEGAL 冲突存在但 status={union_result.get('status')}（应为 TRIGGERED/REJECTED）")

        # 替代路径合法性: 不得穿越禁止领域
        for path in alt_paths:
            if _path_illegal(path):
                illegal_paths.append(f"替代路径 {path} 穿越禁止领域")

        valid = (not legal_conflicts) or (
            not illegal_paths and not reasons
        )
        # premium 校验: [0,1] 区间
        premium_ok = 0.0 <= risk_premium <= 1.0
        if not premium_ok:
            reasons.append(f"risk_premium={risk_premium} 超出 [0,1]")

        return ValidationResult(
            valid=valid and premium_ok,
            legal_conflicts=legal_conflicts,
            illegal_paths=illegal_paths,
            premium_ok=premium_ok,
            reasons=reasons or ["无法律有效性问题"],
        )

    # ------------------------------------------------------------------
    # generate_legal_nca（法学家判断 → 标准 NCA）
    # ------------------------------------------------------------------
    def generate_legal_nca(self, case: dict) -> LegalNCA:
        """铸造标准 NCA（法律依据/冲突类型/严重度/建议处置/审计轨迹）"""
        legal_basis = self._resolve_legal_basis(case)
        severity = case.get("severity", "MEDIUM")
        conflict_type = case.get("conflict_type", "UNKNOWN_CONFLICT")

        # 建议处置（对齐 D-2 schema 处置路径）
        if severity == "HIGH" or case.get("fuse_type") == "LEGAL":
            recommended = "负空间熔断（TRIGGERED）: 禁止跨场景调用, 无替代路径, 转人工审查"
        elif severity == "MEDIUM":
            recommended = "拒绝 + Alt-Path 绕行（FAIL）: 取严规则应用, 推荐替代场景"
        else:
            recommended = "通过 + risk_premium 抬升（PASS, L1 自律）"

        nca_id = f"NCA-LEGAL-{hashlib.sha1(f'{case.get('case_ref', '')}{time.time_ns()}'.encode()).hexdigest()[:8]}"

        return LegalNCA(
            nca_id=nca_id,
            case_ref=case.get("case_ref", ""),
            legal_basis=legal_basis,
            conflict_type=conflict_type,
            severity=severity,
            recommended_action=recommended,
            confidence=float(case.get("confidence", 0.8)),
            audit_trail={
                "channels": case.get("channels", {}),
                "reasoning": case.get("reasoning", ""),
                "schema_version": "D2-NSFL-UNION-SCHEMA-001 V0.1-REV2-FINAL",
            },
            timestamp=int(time.time()),
            human_escalated=case.get("tier") in ("CONFIRM", "ESCALATE"),
        )

    def _resolve_legal_basis(self, case: dict) -> List[str]:
        """依据冲突类型检索法律依据（KG 检索, <200ms）"""
        conflict_type = case.get("conflict_type", "")
        mapping = {
            "DATA_CROSS_BORDER": ["L-CN-DSL-002", "L-CN-PIPL-002", "L-CN-DSL-001"],
            "IP_COPYRIGHT": ["L-CN-CR-001", "L-CN-CR-002"],
            "IP_TRADE_SECRET": ["L-CN-TSL-001"],
            "CONTRACT_EFFECT": ["L-CN-CRL-001", "L-CN-CRL-002"],
            "SENSITIVE_CONTENT": ["L-CN-PIPL-001"],
            "MARKET_ABUSE": ["L-CN-AML-001"],
            "TRANSACTION_LIMIT": ["I-FIN-001", "I-FIN-002"],
            "ADMIN_PERMIT": ["L-CN-AL-001", "L-CN-AL-002"],
        }
        ids = mapping.get(conflict_type, [])
        basis = []
        for nid in ids:
            node = self.kg.nodes.get(nid)
            if node:
                basis.append(f"{node.name}: {node.properties.get('point', '')}")
        if not basis:
            # 兜底: 宪法 L0 基底
            node = self.kg.get_constitution("C07")
            if node:
                basis.append(f"{node.name}: {node.properties.get('text', '')}")
        return basis


def _path_illegal(path: str) -> bool:
    """替代路径非法性检查（阶段 1 简化: 关键词）"""
    illegal_kw = ["禁止", "熔断", "BANNED", "TEARDOWN"]
    return any(k in str(path) for k in illegal_kw)
