# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
"""
TDCA-KG-LEGAL 冲突检测引擎（T-LEGAL-002）— 推理三通道
制度锚定: TDCA-KG-001 推理规则层 + AMEND-1 §2.2（三通道）+ D-2 schema（NS_Type/严重度）
版本: V0.1 | 状态: 开发中
SPDX-License-Identifier: Apache-2.0
NSFL-Declaration:
  - 低置信度（<0.70）强制上报法学家，禁止静默标注
  - LEGAL 型冲突恒 HIGH，不可降级（ID<n>）
  - 判定结果生成审计轨迹
"""

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from legal_agent.kg_legal import KGLegal
from data.kg_legal_seed import SEVERITY_KEYWORDS


@dataclass
class PrelabelResult:
    """prelabel 输出（对齐 D-2 任务书法务衔接 + LegalAgentInterface）"""

    scene_a: str
    scene_b: str
    confidence: float          # [0,1]
    tier: str                  # AUTO（>0.95 直标）| CONFIRM（0.70-0.95 建议标注待确认）| ESCALATE（<0.70 边界案例上报）
    conflict: Optional[dict]   # 冲突明细
    reasoning: str             # 三通道推理依据
    channels: Dict = field(default_factory=dict)  # 各通道输出
    nca_ref: Optional[str] = None


class LegalConflictEngine:
    """推理三通道: 规则匹配 / 案例类比 / 语义推理"""

    def __init__(self, kg: Optional[KGLegal] = None):
        self.kg = kg or KGLegal()

    # ------------------------------------------------------------------
    # 通道 1: 规则匹配（硬约束 → 直接标记冲突, 高置信度）
    # ------------------------------------------------------------------
    def rule_matching(self, scene_a: dict, scene_b: dict) -> dict:
        """基于法律/宪法规则文本匹配的硬约束检测

        输入场景形状（对齐 D-2 SceneNSFL）:
          {"scene_id": ..., "ns_types": [...], "rules": [{"ns_type","operator","parameter","severity","fuse_type"}], "text": "场景描述"}
        """
        t0 = time.perf_counter()
        conflicts = []
        confidence = 0.0
        reasons = []

        rules_a = scene_a.get("rules", []) or []
        rules_b = scene_b.get("rules", []) or []

        # 规则级语义比较（ns_type 相同 + 方向冲突）
        # §5.1 全局制度基底: fuse_type==LEGAL 或 ns_type==LEGAL 的规则强制与对侧所有规则比较
        for ra in rules_a:
            ra_legal = ra.get("fuse_type") == "LEGAL" or ra.get("ns_type") == "LEGAL"
            for rb in rules_b:
                rb_legal = rb.get("fuse_type") == "LEGAL" or rb.get("ns_type") == "LEGAL"
                if not ra_legal and not rb_legal and ra.get("ns_type") != rb.get("ns_type"):
                    continue
                c = self._compare_rules(ra, rb, scene_a["scene_id"], scene_b["scene_id"])
                if c:
                    conflicts.append(c)

        # 场景文本扫描: 法律关键词命中（LEGAL 型恒 HIGH）
        text_a = (scene_a.get("text") or "").lower()
        text_b = (scene_b.get("text") or "").lower()
        for conflict_type, fuse_type, severity, keywords in _LAW_KEYWORD_RULES:
            hit_a = any(k in text_a for k in keywords)
            hit_b = any(k in text_b for k in keywords)
            if hit_a or hit_b:
                conflicts.append({
                    "ns_type": conflict_type,
                    "severity": severity,
                    "fuse_type": fuse_type,
                    "resolution": "FORBID" if severity == "HIGH" else "TAKE_STRICTER",
                    "reason": f"法律规则匹配: {conflict_type}（{'双方' if hit_a and hit_b else '单方'}声明）",
                    "rule_a": {"ns_type": conflict_type, "operator": "FORBID" if hit_a else "ALLOW"},
                    "rule_b": {"ns_type": conflict_type, "operator": "FORBID" if hit_b else "ALLOW"},
                })

        if conflicts:
            max_sev = max(_SEV_RANK[c["severity"]] for c in conflicts)
            confidence = 0.96 if max_sev >= _SEV_RANK["HIGH"] else 0.85
            reasons.append(f"规则匹配通道命中 {len(conflicts)} 条冲突（最高严重度 {_sev_name(max_sev)}）")
        else:
            confidence = 0.6
            reasons.append("规则匹配通道无硬冲突命中")

        return {
            "channel": "rule_matching",
            "conflicts": conflicts,
            "confidence": confidence,
            "reasons": reasons,
            "latency_ms": (time.perf_counter() - t0) * 1000,
        }

    def _compare_rules(self, ra: dict, rb: dict, scene_a_id: str, scene_b_id: str) -> Optional[dict]:
        """单条规则对比较（取严原则, 对齐 D-2 schema §5.2）"""
        op_a, op_b = ra.get("operator"), rb.get("operator")
        ns_type = ra.get("ns_type")
        sev_a, sev_b = ra.get("severity", "MEDIUM"), rb.get("severity", "MEDIUM")
        sev = max(sev_a, sev_b, key=lambda s: _SEV_RANK.get(s, 0))

        # LEGAL 型（fuse_type==LEGAL 或 ns_type==LEGAL）恒 HIGH + FORBID
        if ra.get("fuse_type") == "LEGAL" or rb.get("fuse_type") == "LEGAL" or ns_type == "LEGAL":
            return {
                "ns_type": ns_type, "severity": "HIGH", "fuse_type": "LEGAL",
                "resolution": "FORBID",
                "reason": "LEGAL 绝对熔断（ID<n>）: 含法律禁止语义, 无替代路径",
                "rule_a": ra, "rule_b": rb,
            }

        # 允许 vs 禁止 → 禁止
        if (op_a, op_b) in (("ALLOW", "FORBID"), ("FORBID", "ALLOW")):
            return {
                "ns_type": ns_type, "severity": sev, "fuse_type": ra.get("fuse_type"),
                "resolution": "FORBID",
                "reason": f"允许 vs 禁止冲突（{scene_a_id} {op_a} / {scene_b_id} {op_b}）→ 取禁止",
                "rule_a": ra, "rule_b": rb,
            }

        # 数值约束取严（LIMIT_MAX 取 min / LIMIT_MIN 取 max / LIMIT_EQ 定值）
        if op_a in ("LIMIT_MAX", "LIMIT_MIN", "LIMIT_EQ") and op_b in ("LIMIT_MAX", "LIMIT_MIN", "LIMIT_EQ"):
            pa, pb = ra.get("parameter"), rb.get("parameter")
            if pa is None or pb is None or pa == pb:
                return None
            if op_a == "LIMIT_MAX" and op_b == "LIMIT_MAX":
                return self._mk_conflict(ns_type, sev, "TAKE_STRICTER", min(pa, pb),
                                         f"限额取严: min({pa},{pb})", ra, rb)
            if op_a == "LIMIT_MIN" and op_b == "LIMIT_MIN":
                return self._mk_conflict(ns_type, sev, "TAKE_STRICTER", max(pa, pb),
                                         f"下限取严: max({pa},{pb})", ra, rb)
            # 上下界交叉 → 空域拒绝
            if op_a == "LIMIT_MAX" and op_b == "LIMIT_MIN" and pa < pb:
                return self._mk_conflict(ns_type, sev, "EMPTY_DOMAIN", None,
                                         f"空域: 上界 {pa} < 下界 {pb}", ra, rb)
            if op_a == "LIMIT_MIN" and op_b == "LIMIT_MAX" and pa > pb:
                return self._mk_conflict(ns_type, sev, "EMPTY_DOMAIN", None,
                                         f"空域: 下界 {pa} > 上界 {pb}", ra, rb)
            if op_a == "LIMIT_EQ" and op_b == "LIMIT_EQ":
                return self._mk_conflict(ns_type, sev, "EMPTY_DOMAIN", None,
                                         f"定值矛盾: {pa} vs {pb}", ra, rb)
        return None

    def _mk_conflict(self, ns_type, sev, resolution, value, reason, ra, rb) -> dict:
        return {
            "ns_type": ns_type, "severity": sev, "fuse_type": ra.get("fuse_type"),
            "resolution": resolution, "resolution_value": value, "reason": reason,
            "rule_a": ra, "rule_b": rb,
        }

    # ------------------------------------------------------------------
    # 通道 2: 案例类比（相似场景历史判例 → 推断冲突概率）
    # ------------------------------------------------------------------
    def case_analogy(self, scene_a: dict, scene_b: dict) -> dict:
        t0 = time.perf_counter()
        text_a = (scene_a.get("text") or "").lower()
        text_b = (scene_b.get("text") or "").lower()
        combined = f"{text_a} {text_b}"
        matched = []

        for node in self.kg.nodes.values():
            if node.node_type != "JudicialCase":
                continue
            desc = node.properties.get("description", "").lower()
            # 关键词重合度（简单 Jaccard 近似: 命中词数）
            hits = sum(1 for kw in _CASE_KEYWORDS if kw in desc and kw in combined)
            if hits > 0:
                matched.append((hits, node))

        matched.sort(key=lambda x: -x[0])
        top = matched[:3]
        if not top:
            return {
                "channel": "case_analogy", "cases": [], "confidence": 0.5,
                "reasons": ["无相似判例"],
                "latency_ms": (time.perf_counter() - t0) * 1000,
            }

        max_sev = max(_SEV_RANK.get(n.properties.get("severity", "MEDIUM"), 0) for _, n in top)
        confidence = min(0.9, 0.55 + 0.08 * top[0][0])
        reasons = [
            "案例类比命中 %d 条（%s）: %s" % (
                len(top),
                ", ".join(n.node_id for _, n in top),
                top[0][1].properties.get("verdict"),
            )
        ]
        return {
            "channel": "case_analogy",
            "cases": [n.properties for _, n in top],
            "confidence": confidence,
            "reasons": reasons,
            "max_severity": _sev_name(max_sev),
            "latency_ms": (time.perf_counter() - t0) * 1000,
        }

    # ------------------------------------------------------------------
    # 通道 3: 语义推理（自然语言场景描述 → 法律概念映射 → 冲突检测）
    # ------------------------------------------------------------------
    def semantic_reasoning(self, scene_a: dict, scene_b: dict) -> dict:
        t0 = time.perf_counter()
        text_a = (scene_a.get("text") or "").lower()
        text_b = (scene_b.get("text") or "").lower()

        # 法律概念抽取 + FuseType 映射
        concepts_a = self._extract_concepts(text_a)
        concepts_b = self._extract_concepts(text_b)
        all_concepts = set(concepts_a) | set(concepts_b)

        conflicts = []
        for concept in all_concepts:
            fuse_type = self.kg.get_fuse_type_for_concept(concept)
            if fuse_type is None:
                continue
            sev = _concept_severity(concept, fuse_type)
            hit_a, hit_b = concept in text_a, concept in text_b
            if hit_a and hit_b:
                # 双侧声明同一概念: 方向差异才冲突（阶段 1: 标注为潜在冲突上报）
                conflicts.append({
                    "ns_type": _concept_ns_type(concept),
                    "severity": sev, "fuse_type": fuse_type,
                    "resolution": "UNKNOWN", "reason": f"双侧语义声明 {concept}（需人工确认方向）",
                })
            elif hit_a or hit_b:
                # 单侧声明 + 法律概念 → 非对称冲突（LEGAL 型恒冲突）
                conflicts.append({
                    "ns_type": _concept_ns_type(concept),
                    "severity": sev, "fuse_type": fuse_type,
                    "resolution": "FORBID" if sev == "HIGH" else "UNKNOWN",
                    "reason": f"单侧语义声明 {concept}（fuse_type={fuse_type}）",
                })

        if conflicts:
            max_sev = max(_SEV_RANK[c["severity"]] for c in conflicts)
            confidence = 0.78 if max_sev >= _SEV_RANK["HIGH"] else 0.65
            reasons = [f"语义推理命中 {len(conflicts)} 条（概念: {', '.join(all_concepts) or '无'}）"]
        else:
            confidence = 0.55
            reasons = ["语义推理无法律概念冲突"]

        return {
            "channel": "semantic_reasoning",
            "conflicts": conflicts,
            "concepts": sorted(all_concepts),
            "confidence": confidence,
            "reasons": reasons,
            "latency_ms": (time.perf_counter() - t0) * 1000,
        }

    def _extract_concepts(self, text: str) -> List[str]:
        from data.kg_legal_seed import LEGAL_TO_FUSETYPE_MAP

        found = []
        for concept in LEGAL_TO_FUSETYPE_MAP:
            if concept.lower() in text:
                found.append(concept)
        return found

    # ------------------------------------------------------------------
    # 三通道融合 + prelabel 阈值
    # ------------------------------------------------------------------
    def prelabel(self, scene_a: dict, scene_b: dict) -> PrelabelResult:
        """三通道融合初筛（验收: 高置信度直标一致率 ≥95% / 边界案例召回 ≥80%）"""
        r1 = self.rule_matching(scene_a, scene_b)
        r2 = self.case_analogy(scene_a, scene_b)
        r3 = self.semantic_reasoning(scene_a, scene_b)

        # 融合置信度: 规则匹配为主（硬约束权威）, 案例/语义修正
        confidence = r1["confidence"]
        if r1["conflicts"]:
            confidence = max(confidence, 0.96 if any(
                c["severity"] == "HIGH" for c in r1["conflicts"]
            ) else 0.85)
        else:
            # 无规则冲突: 案例/语义通道补充
            confidence = max(r2["confidence"], r3["confidence"], 0.5)
            if r3["conflicts"]:
                confidence = max(confidence, r3["confidence"])

        # 合并冲突（规则 > 语义 > 案例, 去重）
        conflicts = list(r1["conflicts"])
        seen = {(c["ns_type"], c.get("resolution")) for c in conflicts}
        for c in r3["conflicts"]:
            key = (c["ns_type"], c.get("resolution"))
            if key not in seen:
                conflicts.append(c)
                seen.add(key)

        # prelabel 阈值逻辑（对齐 D-2 任务书 §五.2）:
        #   >0.95 直标 AUTO / 0.70-0.95 建议标注待确认 CONFIRM / <0.70 边界案例上报 ESCALATE
        if confidence > 0.95:
            tier = "AUTO"
        elif confidence >= 0.70:
            tier = "CONFIRM"
        else:
            tier = "ESCALATE"

        # 冲突汇总（取最高严重度）
        conflict_summary = None
        if conflicts:
            max_c = max(conflicts, key=lambda c: _SEV_RANK.get(c["severity"], 0))
            conflict_summary = {
                "ns_type": max_c["ns_type"],
                "severity": max_c["severity"],
                "fuse_type": max_c.get("fuse_type"),
                "resolution": max_c["resolution"],
                "reason": max_c["reason"],
                "conflict_count": len(conflicts),
            }

        reasoning = "; ".join(
            (r1["reasons"] + r2["reasons"] + r3["reasons"])[:4]
        ) or "无冲突"

        return PrelabelResult(
            scene_a=scene_a["scene_id"],
            scene_b=scene_b["scene_id"],
            confidence=round(confidence, 3),
            tier=tier,
            conflict=conflict_summary,
            reasoning=reasoning,
            channels={
                "rule_matching": {"conflicts": r1["conflicts"], "latency_ms": round(r1["latency_ms"], 2)},
                "case_analogy": {"cases": r2.get("cases", []), "latency_ms": round(r2["latency_ms"], 2)},
                "semantic_reasoning": {"conflicts": r3["conflicts"], "concepts": r3.get("concepts", []),
                                       "latency_ms": round(r3["latency_ms"], 2)},
            },
        )


# ----------------------------------------------------------------------
# 常量与工具
# ----------------------------------------------------------------------
_SEV_RANK = {"LOW": 1, "MEDIUM": 2, "HIGH": 3}


def _sev_name(rank: int) -> str:
    for k, v in _SEV_RANK.items():
        if v == rank:
            return k
    return "MEDIUM"


# 法律关键词规则表（规则匹配通道场景文本扫描用）
# R-6 对齐: DATA_CROSS_BORDER 场景化声明（含"允许/禁止跨境"措辞）= L2 MEDIUM；
#          LEGAL 型（法律禁止）须显式"法律"字样 → HIGH；个人信息/隐私类法律强制 → HIGH
_LAW_KEYWORD_RULES = [
    ("DATA_CROSS_BORDER", "ETHICAL", "MEDIUM", ["数据跨境", "跨境传输", "允许跨境", "禁止跨境"]),
    ("LEGAL", "LEGAL", "HIGH", ["法律明文禁止", "法律禁止", "法律规定"]),
    ("DATA_CROSS_BORDER", "LEGAL", "HIGH", ["个人信息", "隐私", "敏感信息"]),
    ("IP_COPYRIGHT", "LEGAL", "HIGH", ["著作权", "版权", "复制权", "盗版"]),
    ("IP_TRADE_SECRET", "LEGAL", "HIGH", ["商业秘密", "商业机密"]),
    ("CONTRACT_EFFECT", "LEGAL", "HIGH", ["合同无效", "意思表示", "公序良俗"]),
    ("SENSITIVE_CONTENT", "LEGAL", "MEDIUM", ["健康数据", "医疗数据", "未成年人"]),
    ("MARKET_ABUSE", "LEGAL", "HIGH", ["垄断", "市场支配", "不公平定价"]),
    ("TRANSACTION_LIMIT", "TECHNICAL", "MEDIUM", ["交易限额", "支付限额", "限额"]),
]

_CASE_KEYWORDS = ["跨境", "数据", "著作权", "商业秘密", "合同", "医疗", "保险", "定价", "算法", "平台"]


def _concept_severity(concept: str, fuse_type: str) -> str:
    """概念严重度: LEGAL 型恒 HIGH（ID<n>）; 其余按关键词档位"""
    if fuse_type == "LEGAL":
        return "HIGH"
    for sev, kws in SEVERITY_KEYWORDS.items():
        for kw in kws:
            if kw in concept:
                return sev
    return "MEDIUM"


def _concept_ns_type(concept: str) -> str:
    mapping = {
        "数据跨境": "DATA_CROSS_BORDER", "个人信息": "DATA_CROSS_BORDER", "隐私": "DATA_CROSS_BORDER",
        "商业秘密": "IP_TRADE_SECRET", "著作权": "IP_COPYRIGHT", "专利": "IP_COPYRIGHT",
        "合同效力": "CONTRACT_EFFECT", "行政许可": "ADMIN_PERMIT", "垄断": "MARKET_ABUSE",
        "金融数据": "TECH_CONSTRAINT", "交易限额": "TRANSACTION_LIMIT", "技术约束": "TECH_CONSTRAINT",
    }
    for k, v in mapping.items():
        if k in concept:
            return v
    return "UNKNOWN_CONFLICT"
