# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
"""
NSFL 预检过滤器（L-2 处置: 涉政/涉隐私案例自动过滤）
制度锚定: DCD-5CC-002-AMEND-1（负空间审查）+ TDCA-TASK-LEGAL-001-002 附录 L-2
版本: V0.1 | 状态: 开发中
SPDX-License-Identifier: Apache-2.0
NSFL-Declaration:
  - 涉政/涉隐私场景自动过滤, 不进入标注流程
  - 过滤记录生成审计轨迹
"""

import re
from typing import List, Optional


# 涉政敏感模式（阶段 1 模拟态: 规则匹配 + 关键词表）
POLITICAL_PATTERNS = [
    r"国家\s*(机密|秘密)", r"涉密", r"国安", r"情报", r"军事\s*(机密|基地)",
    r"领导人\s*(隐私|信息)", r"未公开\s*政策",
]

# 涉隐私敏感模式（个人敏感信息）
PRIVACY_PATTERNS = [
    r"身份证\s*(号|号码)", r"银行卡\s*(号|号码)", r"手机号", r"住址",
    r"健康\s*记录", r"病历", r"生物\s*识别", r"人脸\s*信息", r"指纹",
    r"未成年\s*(人|儿童)\s*(信息|隐私)", r"性取向", r"犯罪\s*记录",
]


class NSFLFilter:
    """负空间预检: 涉政/涉隐私过滤"""

    def __init__(self):
        self._political = [re.compile(p) for p in POLITICAL_PATTERNS]
        self._privacy = [re.compile(p) for p in PRIVACY_PATTERNS]

    def check(self, text: str) -> dict:
        """返回 {blocked: bool, reasons: [..]}"""
        reasons = []
        for pat in self._political:
            if pat.search(text):
                reasons.append(f"POLITICAL_SENSITIVE: {pat.pattern}")
        for pat in self._privacy:
            if pat.search(text):
                reasons.append(f"PRIVACY_SENSITIVE: {pat.pattern}")
        return {"blocked": bool(reasons), "reasons": reasons}

    def filter_scene_pair(self, scene_a: dict, scene_b: dict) -> dict:
        """场景对预检（任一涉政/涉隐私 → 整对拒绝进入标注）"""
        text_a = (scene_a.get("text") or "") + " " + " ".join(
            str(r.get("ns_type", "")) for r in (scene_a.get("rules") or [])
        )
        text_b = (scene_b.get("text") or "") + " " + " ".join(
            str(r.get("ns_type", "")) for r in (scene_b.get("rules") or [])
        )
        ra, rb = self.check(text_a), self.check(text_b)
        reasons = ra["reasons"] + rb["reasons"]
        return {"blocked": bool(reasons), "reasons": reasons, "scene_a_blocked": ra["blocked"], "scene_b_blocked": rb["blocked"]}
