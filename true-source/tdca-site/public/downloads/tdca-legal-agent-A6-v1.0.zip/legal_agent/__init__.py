# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
"""TDCA-AGENT-LEGAL-001 法务智能体包"""
__version__ = "0.1.0"
