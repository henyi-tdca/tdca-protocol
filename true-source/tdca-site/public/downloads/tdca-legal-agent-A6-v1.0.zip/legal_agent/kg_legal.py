# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
"""
TDCA-KG-LEGAL 法律专业知识图谱（T-LEGAL-001）
制度锚定: 知识图谱工程规范（节点/边/推理）+ 宪法十六条权威基准（内部基准件）+ 术语注册表 V1.1
版本: V0.1 | 状态: 开发中
SPDX-License-Identifier: Apache-2.0
NSFL-Declaration:
  - 图谱数据只读引用权威源（宪法 KB / 公开法条），不复制不移动（L-1 处置）
  - 涉政/涉隐私案例自动过滤（L-2 处置）
  - 检索须生成审计轨迹
"""

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from data.kg_legal_seed import (
    CONSTITUTION_ARTICLES,
    CONSTITUTION_SEVERITY,
    LAW_ARTICLES,
    INDUSTRY_STANDARDS,
    JUDICIAL_CASES,
    LEGAL_TO_FUSETYPE_MAP,
    SEVERITY_KEYWORDS,
)


@dataclass
class LegalNode:
    """图谱节点（对齐 TDCA-KG-001 node_types）"""

    node_id: str
    node_type: str  # Constitution | LawArticle | IndustryStandard | JudicialCase | LegalConcept
    name: str
    properties: Dict = field(default_factory=dict)


@dataclass
class LegalEdge:
    """图谱边（对齐 TDCA-KG-001 edge_types: DERIVES_FROM / ENFORCES / MAPS_TO / ANALOGOUS_TO）"""

    source: str
    target: str
    edge_type: str
    properties: Dict = field(default_factory=dict)


class KGLegal:
    """TDCA-KG-LEGAL 四库图谱：制度基线库 / 法律法规库 / 行业规范库 / 司法案例库"""

    def __init__(self, seed_data: Optional[dict] = None):
        self.nodes: Dict[str, LegalNode] = {}
        self.edges: List[LegalEdge] = []
        self._build(seed_data)

    # ------------------------------------------------------------------
    # 图谱构建
    # ------------------------------------------------------------------
    def _build(self, seed_data: Optional[dict]):
        sd = seed_data or {}
        arts = sd.get("constitution", CONSTITUTION_ARTICLES)
        laws = sd.get("laws", LAW_ARTICLES)
        stds = sd.get("standards", INDUSTRY_STANDARDS)
        cases = sd.get("cases", JUDICIAL_CASES)

        # 库 1: 制度基线库（宪法十六条）
        for article_id, principle, text, level in arts:
            self._add_node(
                node_id=article_id,
                node_type="Constitution",
                name=f"宪法第{principle}条（{article_id}）",
                properties={
                    "principle": principle,
                    "text": text,
                    "enforcement_level": level,
                    "severity": CONSTITUTION_SEVERITY.get(article_id, "MEDIUM"),
                    "priority": 5,
                },
            )

        # 库 2: 法律法规库
        for law_id, law_name, article_ref, point, fuse_type, severity in laws:
            self._add_node(
                node_id=law_id,
                node_type="LawArticle",
                name=f"{law_name} {article_ref}",
                properties={
                    "law_name": law_name,
                    "article_ref": article_ref,
                    "point": point,
                    "fuse_type": fuse_type,
                    "severity": severity,
                },
            )
            # 宪法 ENFORCES 边（法律法规是宪法 L0 法律底层映射）
            self._add_edge(law_id, _map_law_to_constitution(law_id), "ENFORCES", {})

        # 库 3: 行业规范库
        for std_id, industry, std_name, point, fuse_type, severity in stds:
            self._add_node(
                node_id=std_id,
                node_type="IndustryStandard",
                name=f"{industry}: {std_name}",
                properties={
                    "industry": industry,
                    "standard_name": std_name,
                    "point": point,
                    "fuse_type": fuse_type,
                    "severity": severity,
                },
            )

        # 库 4: 司法案例库（NSFL 预检: 涉政/涉隐私过滤由 nsfl_filter 在外层执行）
        for case_id, desc, conflict_type, verdict, severity, fuse_type in cases:
            self._add_node(
                node_id=case_id,
                node_type="JudicialCase",
                name=f"案例 {case_id}",
                properties={
                    "description": desc,
                    "conflict_type": conflict_type,
                    "verdict": verdict,
                    "severity": severity,
                    "fuse_type": fuse_type,
                },
            )

        # 法律概念 → FuseType 映射（LegalConcept 节点 + MAPS_TO 边）
        for concept, fuse_type in LEGAL_TO_FUSETYPE_MAP.items():
            concept_id = f"CONCEPT-{_hash_id(concept)}"
            self._add_node(
                node_id=concept_id,
                node_type="LegalConcept",
                name=concept,
                properties={"fuse_type": fuse_type},
            )

    def _add_node(self, node_id: str, node_type: str, name: str, properties: dict):
        if node_id in self.nodes:
            return
        self.nodes[node_id] = LegalNode(
            node_id=node_id, node_type=node_type, name=name, properties=properties
        )

    def _add_edge(self, source: str, target: str, edge_type: str, properties: dict):
        self.edges.append(LegalEdge(source, target, edge_type, properties))

    # ------------------------------------------------------------------
    # 检索接口
    # ------------------------------------------------------------------
    def search_law(self, query: str, limit: int = 5) -> List[LegalNode]:
        """单条法律条文检索（验收: <200ms 本地）"""
        t0 = time.perf_counter()
        q = query.lower()
        results = []
        for node in self.nodes.values():
            if node.node_type != "LawArticle":
                continue
            haystack = f"{node.name} {node.properties.get('point', '')}".lower()
            if q in haystack or q in node.name.lower():
                results.append(node)
            if len(results) >= limit:
                break
        # 无直接命中时降级为关键词扫描（2 字窗口双向匹配, 适配中文检索）
        if not results:
            q_words = _bigrams(query)
            for node in self.nodes.values():
                if node.node_type != "LawArticle":
                    continue
                point = node.properties.get("point", "").lower()
                if any(w in point or point in w for w in q_words):
                    results.append(node)
                if len(results) >= limit:
                    break
        return results

    def search_cases(
        self, conflict_type: str, severity: Optional[str] = None, limit: int = 5
    ) -> List[LegalNode]:
        """案例类比检索（按冲突类型 + 严重度过滤）"""
        results = []
        for node in self.nodes.values():
            if node.node_type != "JudicialCase":
                continue
            props = node.properties
            if props.get("conflict_type") != conflict_type:
                continue
            if severity and props.get("severity") != severity:
                continue
            results.append(node)
            if len(results) >= limit:
                break
        return results

    def get_fuse_type_for_concept(self, concept: str) -> Optional[str]:
        """法律概念 → FuseType 映射查询（防语义漂移 R-LEGAL-002）"""
        # 先精确映射
        if concept in LEGAL_TO_FUSETYPE_MAP:
            return LEGAL_TO_FUSETYPE_MAP[concept]
        # 再子串匹配
        for k, v in LEGAL_TO_FUSETYPE_MAP.items():
            if k in concept or concept in k:
                return v
        return None

    def get_constitution(self, article_id: str) -> Optional[LegalNode]:
        return self.nodes.get(article_id)

    def stats(self) -> dict:
        counts: Dict[str, int] = {}
        for node in self.nodes.values():
            counts[node.node_type] = counts.get(node.node_type, 0) + 1
        return {"nodes": len(self.nodes), "edges": len(self.edges), "by_type": counts}


# ----------------------------------------------------------------------
# 工具
# ----------------------------------------------------------------------
def _hash_id(s: str) -> str:
    import hashlib

    return hashlib.sha1(s.encode("utf-8")).hexdigest()[:8]


def _extract_keywords(query: str, max_kw: int = 3) -> List[str]:
    """简单关键词抽取（2-4 字符窗口扫描）"""
    q = query.lower()
    kws = []
    for length in (4, 3, 2):
        for i in range(len(q) - length + 1):
            seg = q[i : i + length]
            if seg not in kws and not seg.isdigit():
                kws.append(seg)
            if len(kws) >= max_kw:
                return kws
    return kws


def _bigrams(text: str) -> List[str]:
    """2 字窗口切分（中文检索降级匹配用）"""
    t = text.lower().strip()
    if len(t) <= 2:
        return [t] if t else []
    return [t[i : i + 2] for i in range(len(t) - 1)]


def _map_law_to_constitution(law_id: str) -> str:
    """法律 → 宪法条款映射（L0 法律底层映射）"""
    mapping = {
        "DSL": "C12", "PIPL": "C12", "CRL": "C14", "CR-": "C13",
        "PL-": "C13", "TSL": "C13", "AL-": "C15", "AML": "C02",
        "EL": "C14", "NL": "C12",
    }
    for prefix, article in mapping.items():
        if law_id.startswith(prefix):
            return article
    return "C07"
