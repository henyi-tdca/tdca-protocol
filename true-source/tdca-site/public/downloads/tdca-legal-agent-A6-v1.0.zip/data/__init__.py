# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
"""TDCA-KG-LEGAL 数据包"""
