# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
"""
TDCA-AGENT-LEGAL-001 测试套件
验收映射: T-LEGAL-001（图谱 schema/四库覆盖/检索<200ms/FuseType 映射）
         T-LEGAL-002（初筛准确率/边界案例召回/一致性校验/接口对齐/性能<500ms）
         L-2 处置（涉政/涉隐私过滤）
"""

import time

import pytest

from data.kg_legal_seed import (
    CONSTITUTION_ARTICLES,
    LAW_ARTICLES,
    INDUSTRY_STANDARDS,
    JUDICIAL_CASES,
)
from legal_agent.conflict_engine import LegalConflictEngine
from legal_agent.interface import LegalAgentInterface
from legal_agent.kg_legal import KGLegal
from legal_agent.nsfl_filter import NSFLFilter


# ----------------------------------------------------------------------
# fixtures
# ----------------------------------------------------------------------
@pytest.fixture
def kg():
    return KGLegal()


@pytest.fixture
def engine():
    return LegalConflictEngine()


@pytest.fixture
def agent():
    return LegalAgentInterface()


def _scene(scene_id, text, rules=None, ns_types=None):
    return {
        "scene_id": scene_id,
        "text": text,
        "rules": rules or [],
        "ns_types": ns_types or [],
    }


# ======================================================================
# T-LEGAL-001: 图谱构建与四库覆盖
# ======================================================================
class TestKGLegal:
    def test_constitution_100pct_nodes(self, kg):
        """宪法十六条 100% 节点化（验收标准）"""
        cons = [n for n in kg.nodes.values() if n.node_type == "Constitution"]
        assert len(cons) == 16, f"宪法节点数 {len(cons)} != 16"

    def test_law_at_least_5_major_laws(self, kg):
        """L0 法律 ≥5 部主干法律（验收标准）"""
        laws = [n for n in kg.nodes.values() if n.node_type == "LawArticle"]
        law_names = {n.properties["law_name"] for n in laws}
        assert len(law_names) >= 5, f"主干法律数 {len(law_names)} < 5"
        assert len(laws) >= 5

    def test_industry_at_least_3_scenes(self, kg):
        """行业规范 ≥3 类场景（验收标准）"""
        stds = [n for n in kg.nodes.values() if n.node_type == "IndustryStandard"]
        industries = {n.properties["industry"] for n in stds}
        assert len(industries) >= 3, f"行业场景数 {len(industries)} < 3"

    def test_judicial_cases_present(self, kg):
        cases = [n for n in kg.nodes.values() if n.node_type == "JudicialCase"]
        assert len(cases) >= 5

    def test_schema_alignment(self, kg):
        """图谱 schema 对齐 TDCA-KG-001: 节点类型 + 边类型"""
        node_types = {n.node_type for n in kg.nodes.values()}
        assert node_types >= {"Constitution", "LawArticle", "IndustryStandard", "JudicialCase", "LegalConcept"}
        assert len(kg.edges) > 0
        edge_types = {e.edge_type for e in kg.edges}
        assert "ENFORCES" in edge_types

    def test_law_retrieval_latency(self, kg):
        """单条法律条文检索 <200ms（验收标准）"""
        t0 = time.perf_counter()
        results = kg.search_law("数据跨境")
        elapsed = (time.perf_counter() - t0) * 1000
        assert elapsed < 200, f"检索耗时 {elapsed}ms >= 200ms"
        assert len(results) >= 1

    def test_fuse_type_mapping(self, kg):
        """法律概念 → FuseType 映射表（R-LEGAL-002 防语义漂移）"""
        assert kg.get_fuse_type_for_concept("数据跨境") == "LEGAL"
        assert kg.get_fuse_type_for_concept("交易限额") == "TECHNICAL"
        assert kg.get_fuse_type_for_concept("商业秘密") == "LEGAL"

    def test_unknown_concept_none(self, kg):
        assert kg.get_fuse_type_for_concept("完全未知的概念xyz") is None

    def test_search_law_keyword_fallback(self, kg):
        """检索降级路径: 2 字窗口双向匹配"""
        results = kg.search_law("跨境")
        assert len(results) >= 1

    def test_search_law_no_hit(self, kg):
        results = kg.search_law("完全无关的xxyyzz")
        assert results == []

    def test_search_cases_by_type(self, kg):
        """案例类比检索（按冲突类型 + 严重度过滤）"""
        cases = kg.search_cases("DATA_CROSS_BORDER", "HIGH")
        assert len(cases) >= 1
        assert all(c.properties["conflict_type"] == "DATA_CROSS_BORDER" for c in cases)

    def test_search_cases_no_match(self, kg):
        assert kg.search_cases("NONEXISTENT_TYPE") == []

    def test_get_constitution(self, kg):
        node = kg.get_constitution("C07")
        assert node is not None
        assert node.properties["severity"] == "HIGH"
        assert kg.get_constitution("C99") is None

    def test_stats(self, kg):
        s = kg.stats()
        assert s["nodes"] == len(kg.nodes)
        assert s["by_type"]["Constitution"] == 16
        assert s["by_type"]["LawArticle"] == len(LAW_ARTICLES)
        assert s["by_type"]["IndustryStandard"] == len(INDUSTRY_STANDARDS)
        assert s["by_type"]["JudicialCase"] == len(JUDICIAL_CASES)

    def test_constitution_enforcement_levels(self, kg):
        """宪法硬约束 HARD 条款严重度恒 HIGH"""
        for article_id, _, _, level in CONSTITUTION_ARTICLES:
            node = kg.get_constitution(article_id)
            if level == "HARD":
                assert node.properties["severity"] in ("HIGH", "MEDIUM")
            elif level == "SOFT":
                assert node.properties["severity"] == "LOW"


# ======================================================================
# T-LEGAL-002: 冲突检测引擎三通道
# ======================================================================
class TestConflictEngine:
    def test_rule_matching_allow_forbid(self, engine):
        """允许 vs 禁止 → 禁止冲突"""
        a = _scene("A", "文旅场景允许数据跨境用于游客服务",
                   rules=[{"ns_type": "DATA_CROSS_BORDER", "operator": "ALLOW", "severity": "MEDIUM", "fuse_type": "ETHICAL"}])
        b = _scene("B", "农产品场景禁止数据跨境",
                   rules=[{"ns_type": "DATA_CROSS_BORDER", "operator": "FORBID", "severity": "MEDIUM", "fuse_type": "ETHICAL"}])
        r = engine.rule_matching(a, b)
        assert len(r["conflicts"]) >= 1
        assert r["conflicts"][0]["resolution"] == "FORBID"

    def test_rule_matching_limit_take_stricter(self, engine):
        """交易限额取严: 100 万 vs 50 万 → 50 万"""
        a = _scene("A", "金融场景",
                   rules=[{"ns_type": "TRANSACTION_LIMIT", "operator": "LIMIT_MAX", "parameter": 1000000, "severity": "MEDIUM", "fuse_type": "TECHNICAL"}])
        b = _scene("B", "支付场景",
                   rules=[{"ns_type": "TRANSACTION_LIMIT", "operator": "LIMIT_MAX", "parameter": 500000, "severity": "MEDIUM", "fuse_type": "TECHNICAL"}])
        r = engine.rule_matching(a, b)
        assert len(r["conflicts"]) == 1
        assert r["conflicts"][0]["resolution"] == "TAKE_STRICTER"
        assert r["conflicts"][0]["resolution_value"] == 500000

    def test_legal_fuse_always_high(self, engine):
        """LEGAL 型冲突恒 HIGH + FORBID（ID<n>）"""
        a = _scene("A", "文旅场景",
                   rules=[{"ns_type": "DATA_CROSS_BORDER", "operator": "ALLOW", "severity": "MEDIUM", "fuse_type": "ETHICAL"}])
        b = _scene("B", "涉密场景",
                   rules=[{"ns_type": "LEGAL", "operator": "FORBID", "severity": "MEDIUM", "fuse_type": "LEGAL"}])
        r = engine.rule_matching(a, b)
        assert r["conflicts"][0]["severity"] == "HIGH"
        assert r["conflicts"][0]["fuse_type"] == "LEGAL"

    def test_case_analogy_matches(self, engine):
        a = _scene("A", "电商平台向境外传输用户浏览记录")
        b = _scene("B", "数据服务商跨境数据协作")
        r = engine.case_analogy(a, b)
        assert r["cases"]  # 命中判例

    def test_semantic_reasoning_concept(self, engine):
        a = _scene("A", "平台将用户个人信息用于跨场景定价")
        b = _scene("B", "农产品数据协作不涉及个人信息")
        r = engine.semantic_reasoning(a, b)
        assert "个人信息" in r["concepts"]

    def test_prelabel_tier_auto_high_conf(self, engine):
        """HIGH 冲突 → 高置信度直标（AUTO）"""
        a = _scene("A", "平台未经同意将商业秘密植入智能体用于跨场景调用",
                   rules=[{"ns_type": "IP_TRADE_SECRET", "operator": "ALLOW", "severity": "MEDIUM", "fuse_type": "ETHICAL"}])
        b = _scene("B", "场景禁止商业秘密使用",
                   rules=[{"ns_type": "IP_TRADE_SECRET", "operator": "FORBID", "severity": "MEDIUM", "fuse_type": "ETHICAL"}])
        r = engine.prelabel(a, b)
        assert r.confidence > 0.95
        assert r.tier == "AUTO"
        assert r.conflict is not None

    def test_prelabel_tier_escalate_low_conf(self, engine):
        """无冲突低置信 → 边界案例上报（ESCALATE）"""
        a = _scene("A", "农业合作社内部数据整理")
        b = _scene("B", "手工艺品电商库存管理")
        r = engine.prelabel(a, b)
        assert r.confidence < 0.70
        assert r.tier == "ESCALATE"

    def test_prelabel_performance(self, engine):
        """单场景对初筛 <500ms（验收标准）"""
        a = _scene("A", "金融场景数据跨境与交易限额",
                   rules=[{"ns_type": "DATA_CROSS_BORDER", "operator": "ALLOW", "severity": "MEDIUM", "fuse_type": "ETHICAL"}])
        b = _scene("B", "支付场景禁止跨境",
                   rules=[{"ns_type": "DATA_CROSS_BORDER", "operator": "FORBID", "severity": "MEDIUM", "fuse_type": "ETHICAL"}])
        t0 = time.perf_counter()
        engine.prelabel(a, b)
        elapsed = (time.perf_counter() - t0) * 1000
        assert elapsed < 500, f"初筛耗时 {elapsed}ms >= 500ms"

    def test_high_conf_accuracy_vs_expected(self, engine):
        """高置信度（>0.95）标注与预期法学家判断一致率（验收: ≥95%）
        构造已知结果场景集, 校验 AUTO 档结果方向正确（R-6: 场景化跨境=MEDIUM / 法律禁止=HIGH）"""
        cases = [
            (("文旅允许跨境", "农产品禁止跨境"), "DATA_CROSS_BORDER", "MEDIUM"),
            (("金融限额100万", "支付限额50万"), "TRANSACTION_LIMIT", "MEDIUM"),
            (("法律禁止数据跨境", "文旅允许跨境"), "LEGAL", "HIGH"),
        ]
        correct = 0
        for (ta, tb), exp_type, exp_sev in cases:
            r = engine.prelabel(_scene("A", ta), _scene("B", tb))
            if r.conflict and r.conflict["ns_type"] == exp_type and r.conflict["severity"] == exp_sev:
                correct += 1
        assert correct / len(cases) >= 0.95, f"一致率 {correct}/{len(cases)}"

    def test_consistency_validation(self, agent):
        """一致性校验: 分歧点标记（多法学家交叉验证由接口层支撑）"""
        # validate 输入 D-2 并集引擎输出形状
        union = {
            "status": "TRIGGERED",
            "conflict_set": [
                {"ns_type": "LEGAL", "severity": "HIGH", "fuse_type": "LEGAL", "alt_path": None}
            ],
            "recommended_alt_path": [],
            "risk_premium": 1.0,
        }
        vr = agent.validate(union)
        assert vr.legal_conflicts
        assert vr.valid

    def test_rule_matching_limit_min_take_stricter(self, engine):
        """下限取严: LIMIT_MIN 取 max"""
        a = _scene("A", "支付场景",
                   rules=[{"ns_type": "TRANSACTION_LIMIT", "operator": "LIMIT_MIN", "parameter": 1000, "severity": "MEDIUM", "fuse_type": "TECHNICAL"}])
        b = _scene("B", "金融场景",
                   rules=[{"ns_type": "TRANSACTION_LIMIT", "operator": "LIMIT_MIN", "parameter": 5000, "severity": "MEDIUM", "fuse_type": "TECHNICAL"}])
        r = engine.rule_matching(a, b)
        assert len(r["conflicts"]) == 1
        assert r["conflicts"][0]["resolution"] == "TAKE_STRICTER"
        assert r["conflicts"][0]["resolution_value"] == 5000

    def test_rule_matching_empty_domain(self, engine):
        """上下界交叉 → 空域拒绝"""
        a = _scene("A", "场景A",
                   rules=[{"ns_type": "TRANSACTION_LIMIT", "operator": "LIMIT_MAX", "parameter": 100, "severity": "MEDIUM", "fuse_type": "TECHNICAL"}])
        b = _scene("B", "场景B",
                   rules=[{"ns_type": "TRANSACTION_LIMIT", "operator": "LIMIT_MIN", "parameter": 200, "severity": "MEDIUM", "fuse_type": "TECHNICAL"}])
        r = engine.rule_matching(a, b)
        assert any(c["resolution"] == "EMPTY_DOMAIN" for c in r["conflicts"])

    def test_rule_matching_no_conflict_identical(self, engine):
        """相同规则无冲突"""
        a = _scene("A", "场景A",
                   rules=[{"ns_type": "TRANSACTION_LIMIT", "operator": "LIMIT_MAX", "parameter": 100, "severity": "MEDIUM", "fuse_type": "TECHNICAL"}])
        b = _scene("B", "场景B",
                   rules=[{"ns_type": "TRANSACTION_LIMIT", "operator": "LIMIT_MAX", "parameter": 100, "severity": "MEDIUM", "fuse_type": "TECHNICAL"}])
        r = engine.rule_matching(a, b)
        assert r["conflicts"] == []

    def test_prelabel_multi_conflict_summary(self, engine):
        """多冲突: 汇总取最高严重度"""
        a = _scene("A", "法律禁止数据跨境且含商业秘密",
                   rules=[{"ns_type": "TRANSACTION_LIMIT", "operator": "LIMIT_MAX", "parameter": 100, "severity": "MEDIUM", "fuse_type": "TECHNICAL"}])
        b = _scene("B", "文旅允许跨境",
                   rules=[{"ns_type": "TRANSACTION_LIMIT", "operator": "LIMIT_MAX", "parameter": 50, "severity": "MEDIUM", "fuse_type": "TECHNICAL"}])
        r = engine.prelabel(a, b)
        assert r.conflict is not None
        assert r.conflict["severity"] in ("MEDIUM", "HIGH")

    def test_semantic_no_concept(self, engine):
        r = engine.semantic_reasoning(_scene("A", "农业合作社库存"), _scene("B", "手工艺品电商"))
        assert r["concepts"] == []
        assert r["confidence"] < 0.7

    def test_validate_rejects_illegal_alt_path(self, agent):
        """LEGAL 冲突 + 替代路径 → 非法路径标记"""
        union = {
            "status": "TRIGGERED",
            "conflict_set": [
                {"ns_type": "LEGAL", "severity": "HIGH", "fuse_type": "LEGAL", "alt_path": "SCN-C"}
            ],
            "recommended_alt_path": ["SCN-C"],
            "risk_premium": 0.5,
        }
        vr = agent.validate(union)
        assert not vr.valid
        assert vr.illegal_paths
        assert "risk_premium" in " ".join(vr.reasons)

    def test_validate_pass_no_conflict(self, agent):
        union = {"status": "PASS", "conflict_set": [], "recommended_alt_path": [], "risk_premium": 0.2}
        vr = agent.validate(union)
        assert vr.valid

    def test_generate_legal_nca(self, agent):
        nca = agent.generate_legal_nca({
            "case_ref": "SCN-A-001↔SCN-B-001",
            "conflict_type": "DATA_CROSS_BORDER",
            "severity": "HIGH",
            "fuse_type": "LEGAL",
            "confidence": 0.98,
            "tier": "AUTO",
            "reasoning": "数据出境未评估",
        })
        assert nca.nca_id.startswith("NCA-LEGAL-")
        assert nca.legal_basis  # 法律依据非空
        assert "熔断" in nca.recommended_action
        assert nca.human_escalated is False


# ======================================================================
# NSFL 预检（L-2 处置）
# ======================================================================
class TestNSFLFilter:
    def test_political_blocked(self):
        f = NSFLFilter()
        r = f.check("涉及国家机密信息的场景")
        assert r["blocked"]
        assert any("POLITICAL" in x for x in r["reasons"])

    def test_privacy_blocked(self):
        f = NSFLFilter()
        r = f.check("包含身份证号码与健康记录的数据")
        assert r["blocked"]

    def test_clean_text_pass(self):
        f = NSFLFilter()
        r = f.check("农产品供需匹配场景")
        assert not r["blocked"]

    def test_prelabel_blocked_escalates(self, agent):
        """涉政场景对 → 强制 ESCALATE（不自动标注）"""
        a = _scene("A", "涉及国家秘密的跨场景数据调用")
        b = _scene("B", "普通文旅场景")
        r = agent.prelabel(a, b)
        assert r.tier == "ESCALATE"
        assert r.confidence == 0.0


# ======================================================================
# 冷启动标注冒烟（L-3 处置: 合成数据冒烟 + H 内部标注先行）
# ======================================================================
class TestColdStartSmoke:
    def test_batch_prelabel_smoke(self, agent):
        """合成 20 对场景批量初筛冒烟（冷启动路径验证）"""
        pairs = [
            ("文旅允许跨境数据", "农产品禁止跨境"),
            ("金融限额100万", "支付限额50万"),
            ("电商平台共享用户个人信息", "数据服务商联合建模"),
            ("AI训练使用公开文章", "版权方主张侵权"),
            ("医疗数据用于保险定价", "健康服务场景"),
            ("农业合作社库存管理", "手工艺品电商"),
            ("平台算法差异化定价", "小微商户"),
            ("跨境文旅境外服务器存储", "境内用户数据"),
            ("合同约定自动扣款", "支付场景"),
            ("行业信用名单管理", "跨场景信用评估"),
        ] * 2
        results = [agent.prelabel(_scene(f"A{i}", a), _scene(f"B{i}", b)) for i, (a, b) in enumerate(pairs)]
        tiers = {r.tier for r in results}
        assert tiers <= {"AUTO", "CONFIRM", "ESCALATE"}
        # 每对必有 tier + 耗时合规
        for r in results:
            total = sum(c.get("latency_ms", 0) for c in r.channels.values() if isinstance(c, dict))
            assert total < 500, f"场景对 {r.scene_a}↔{r.scene_b} 通道总耗时 {total}ms"

    def test_tier_distribution_sanity(self, agent):
        """20 对场景: AUTO/CONFIRM/ESCALATE 均有出现（阈值逻辑覆盖）"""
        pairs = [
            ("法律禁止数据跨境", "文旅允许跨境"),
            ("文旅允许跨境", "农产品禁止跨境"),
            ("农业合作社库存", "手工艺品电商"),
            ("金融限额100万", "支付限额50万"),
        ] * 5
        results = [agent.prelabel(_scene(f"A{i}", a), _scene(f"B{i}", b)) for i, (a, b) in enumerate(pairs)]
        tiers = {r.tier for r in results}
        assert "AUTO" in tiers and "ESCALATE" in tiers
