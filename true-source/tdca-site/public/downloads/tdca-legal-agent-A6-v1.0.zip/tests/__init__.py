# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
"""TDCA-AGENT-LEGAL-001 测试套件（SESS-LEGAL-001）"""
