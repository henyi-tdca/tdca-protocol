# TDCA 法务智能体 A-6（tdca-legal-agent）

## 是什么

法学家工作的**放大器与一致性校验器——不替代法学家**：

1. **批量初筛**（高置信度直接标注，低置信度上报法学家）
2. **一致性校验**（多法学家标注交叉验证，标记分歧）
3. **NCA 铸造**（法学家判断 → 结构化 NCA，含法律依据／冲突类型／严重度／审计轨迹）

件面：

| 件 | 做什么 |
|---|---|
| `legal_agent/kg_legal.py` | 法律专业知识图谱（制度基线／法律法规／行业规范／司法案例 四库） |
| `legal_agent/conflict_engine.py` | 冲突检测引擎三通道（规则匹配／案例类比／语义推理） |
| `legal_agent/nsfl_filter.py` | NSFL 预检（涉政／涉隐私过滤） |
| `legal_agent/interface.py` | 统一接口（prelabel／validate／generate_legal_nca） |
| `data/kg_legal_seed.py` | 四库种子数据（宪法十六条／L0 法律／行业规范／案例） |
| `tests/test_legal_agent.py` | 验证件 |

禁止项（继承项目主线）：不替代法学家／涉政涉隐私案例自动过滤／低置信度强制上报／NCA 存证不可缺失。

## 依赖

Python ≥ 3.10，仅标准库。

## 怎么跑（一行命令示例）

```bash
python -m pytest tests/ -q          # 跑验证件
python -c "from legal_agent.interface import LegalAgentInterface; print('import OK')"
```

## 许可

Apache-2.0（见 `LICENSE`）。各件头已标 `SPDX-License-Identifier: Apache-2.0`。
