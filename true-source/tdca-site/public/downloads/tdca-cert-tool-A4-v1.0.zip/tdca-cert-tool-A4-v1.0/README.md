# TDCA-CERT L1 兼容性认证工具（tdca-cert-tool，A-4 货架包）

## 这是什么

TDCA L1 兼容性认证测试套件：判定一个被认证实现是否与 TDCA 官方核心引擎兼容，
覆盖 MCP 桥接连通、准入三态（PASS/REJECT/BLOCK）、存证哈希链、NSFL 熔断分级
（WARN/BLOCK/FUSED）与公理 6 可审计性。
本包为 A-4「证书工具」货架发行包（单文件 `cert_l1.py`）。

## 依赖

- Python ≥ 3.10，**仅标准库**。

## 怎么跑

查看全部命令：

```bash
python cert_l1.py --help
```

官方实现自检（需可达 `tdcad` 官方基线，否则按输出提示处理）：

```bash
python cert_l1.py --selfcheck
```

认证第三方实现（MCP stdio 端点）：

```bash
python cert_l1.py --endpoint "python /path/to/impl_server.py"
```

## 许可

Apache License 2.0（见随包 `LICENSE` 全文）。本包以货架形态对外提供，
不代表对许可范围外任何权利的声称；认证结果为兼容性/合规性判定，不替代开源授权。
